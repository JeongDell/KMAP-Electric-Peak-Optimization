# 실험 20261004T040425_KST_cffc42_loss_c_fivefold_final_events_peak_event_long_3d_xgboost_future_F1_w0_small_a9bc356b

- 상태: 완료
- 목적과 가설: 미래 전체 경로의 최대전력이 원점 기준 B를 초과할 확률을 직접 이진 분류한다. 확률 보정 여부는 같은 5-fold Brier로 비교한다.
- 시작·종료 시각 및 시간대: 2026-10-04T07:39:18.790000+09:00 / 2026-10-04T07:39:19.164710+09:00, Asia/Seoul.
- 모델·라이브러리 버전: xgboost classifier; {'numpy': '2.1.3', 'pandas': '2.2.3', 'scikit-learn': '1.6.1', 'xgboost': '3.4.1', 'lightgbm': '4.7.0', 'catboost': '1.2.10', 'joblib': '1.4.2', 'nbclient': '0.10.2'}; interpreter=C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\.venv_boosting\Scripts\python.exe.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv, SHA256=0173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7; 완료 fold=['sep']; q90=170은 전체 기간에서 계산했다.
- 목표값·단위·예측 구간: max_h power_15min > B(origin)의 이진 사건, power kW, probability 0~1; long_3d.
- 학습·검증·테스트 분할과 누수 점검: 동결 후 9월 재평가; 각 fold 이전 보정 창=28d. base 학습의 전체 H 끝<보정시작, 보정 전체H끝<검증월시작. 미래 power 중간입력 없음. 9월 선택 사용 없음.
- 전처리·특성·하이퍼파라미터·seed: F1, context=None, future, small, {'objective': 'binary:logistic', 'eval_metric': 'logloss', 'tree_method': 'hist', 'n_estimators': 120, 'max_depth': 3, 'learning_rate': 0.05, 'min_child_weight': 10, 'reg_lambda': 10, 'subsample': 0.9, 'colsample_bytree': 0.9, 'random_state': 42, 'n_jobs': 2}; seed42; origin 요약 입력과 알려진 B를 추가. 클래스 재가중·복제 없음.
- 이전 또는 기준 실험 링크와 변경 사항: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\experiments\xgboost\20261003T182425_KST_e84d50_performance_long_3d_xgboost_future_F3_pooled.md; 구간 사건 경험 빈도 기준선, raw/monotone sigmoid 보정 비교. 점 모델과 분류 모델의 목적이 다르다.
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: .venv_boosting/Scripts/python.exe -B -X utf8 notebooks/_shared/finalize_loss_c_fivefold.py; SHA256=0ab5153adb44d91e509e63a1d337fe0eaeabc9a62cb43077d462a85c92895626.
- 실제 실행 시간·자원 사용량(측정한 경우): 0.370s; base fit=1, 보정 fit=1; CPU2threads; fold경계 RSS=493.2MiB, 실제 peak 미측정.
- 평가 지표·구간별 또는 fold별 결과: 아래 표. Brier 주지표, log loss 보조. 두 클래스가 없는 AUROC/AP는 미측정. 경보0.5는 진단이고 최적 운영 임계값이 아니다.
- 기준모델 대비 변화와 비교 가능 여부: 동일 origin/B/path 사건의 사전 학습 경험 빈도와 비교. 개발 5-fold 평균과 9월은 별도다.
- 오차가 큰 조건·해석·한계: 장기 월별27~28경로, 경로 중첩. F1에도 사건 정의에 필요한 B(관측 전력 기반)를 입력하여 point F1과 정보 계약이 다르다. 미래 외생은 실측 대체 오차0 가정. 전체 q90와 이미 본9월로 인해 탐색 평가.
- 오류·경고·실패 또는 중단 원인: 없음; [].
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\performance\runs\20261004T040425_KST_cffc42_loss_c_fivefold\20261004T040425_KST_cffc42_loss_c_fivefold_final_events\peak_event\long_3d\xgboost\future_F1_w0_small_a9bc356b; probabilities, fit/calibration origins, model/calibrator joblib, features, reliability CSV, config/state/metrics.
- 결론과 다음 실험: 완료5fold만 비교하고 raw/calibration/모델/F 선택을9월전에 동결한다. 단일 클래스 fit은 Jeffreys 상수확률로 기록한다.

| n_origins | n_positive | event_rate | Brier | LogLoss | AUROC | AP | mean_probability | recall_at_05 | precision_at_05 | true_positive | false_positive | false_negative | fold | method | n_fit | n_calibration | n_fit_positive | n_calibration_positive | base_single_class | n_features | fit_save_seconds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 12 | 4 | 0.3333 | 0.2744 | 0.8096 | 0.1875 | 0.2833 | 0.1931 | 0.0000 | None | 0 | 0 | 4 | sep | raw | 183 | 25 | 38 | 5 | False | 52 | 0.1161 |
| 12 | 4 | 0.3333 | 0.2878 | 0.8739 | 0.1875 | 0.2833 | 0.1855 | 0.0000 | None | 0 | 0 | 4 | sep | calibrated | 183 | 25 | 38 | 5 | False | 52 | 0.1199 |
| 12 | 4 | 0.3333 | 0.2386 | 0.6810 | 0.5000 | 0.3333 | 0.2052 | 0.0000 | None | 0 | 0 | 4 | sep | baseline | 183 | 25 | 38 | 5 | False | 52 | 0.1233 |


## 동결 후 9월 실제 분할과 민감도

- 선택된 출력은 raw; 선택 동결 SHA256=e788d27a4770724ec3d37fe20bc662b019e82ddd4b1a30db8daf8dd10c86186a. 알려진 9월 재평가이며 추가 튜닝 없음.
- fit 원점: 2021-01-30 00:00:00 ~ 2021-07-31 00:00:00, n=183; 마지막 전체 H 종료=2021-08-03 00:00:00.
- calibration 원점: 2021-08-04 00:00:00 ~ 2021-08-28 00:00:00, n=25; 마지막 전체 H 종료=2021-08-31 00:00:00.
- 보정용 라벨은 base 학습과 분리했다. 목표 보정, 최대 과거지원 전력 및 현재 월 B 산정 이력의 보정 여부를 포함한 공통 scope를 보고한다.

| profile | model | scenario_key | feature_set | context_days | spec_key | method | selected_method | scope | n_excluded_origins | n_origins | n_positive | event_rate | Brier | LogLoss | AUROC | AP | mean_probability | recall_at_05 | precision_at_05 | true_positive | false_positive | false_negative |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| long_3d | xgboost | future | F1 | None | a9bc356b2456de900a7f2654719200b7ac433a3918295bf76926551af7a90541 | raw | raw | full | 0 | 12 | 4 | 0.3333 | 0.2744 | 0.8096 | 0.1875 | 0.2833 | 0.1931 | 0.0000 | nan | 0.0000 | 0.0000 | 4.0000 |
| long_3d | xgboost | future | F1 | None | a9bc356b2456de900a7f2654719200b7ac433a3918295bf76926551af7a90541 | calibrated | raw | full | 0 | 12 | 4 | 0.3333 | 0.2878 | 0.8739 | 0.1875 | 0.2833 | 0.1855 | 0.0000 | nan | 0.0000 | 0.0000 | 4.0000 |
| long_3d | xgboost | future | F1 | None | a9bc356b2456de900a7f2654719200b7ac433a3918295bf76926551af7a90541 | baseline | raw | full | 0 | 12 | 4 | 0.3333 | 0.2386 | 0.6810 | 0.5000 | 0.3333 | 0.2052 | 0.0000 | nan | 0.0000 | 0.0000 | 4.0000 |
| long_3d | xgboost | future | F1 | None | a9bc356b2456de900a7f2654719200b7ac433a3918295bf76926551af7a90541 | raw | raw | clean_targets | 3 | 9 | 3 | 0.3333 | 0.2686 | 0.7919 | 0.2222 | 0.2897 | 0.1951 | 0.0000 | nan | 0.0000 | 0.0000 | 3.0000 |
| long_3d | xgboost | future | F1 | None | a9bc356b2456de900a7f2654719200b7ac433a3918295bf76926551af7a90541 | calibrated | raw | clean_targets | 3 | 9 | 3 | 0.3333 | 0.2800 | 0.8487 | 0.2222 | 0.2897 | 0.1879 | 0.0000 | nan | 0.0000 | 0.0000 | 3.0000 |
| long_3d | xgboost | future | F1 | None | a9bc356b2456de900a7f2654719200b7ac433a3918295bf76926551af7a90541 | baseline | raw | clean_targets | 3 | 9 | 3 | 0.3333 | 0.2386 | 0.6810 | 0.5000 | 0.3333 | 0.2052 | 0.0000 | nan | 0.0000 | 0.0000 | 3.0000 |
| long_3d | xgboost | future | F1 | None | a9bc356b2456de900a7f2654719200b7ac433a3918295bf76926551af7a90541 | raw | raw | clean_targets_inputs | 12 | 0 | 0 | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan |
| long_3d | xgboost | future | F1 | None | a9bc356b2456de900a7f2654719200b7ac433a3918295bf76926551af7a90541 | calibrated | raw | clean_targets_inputs | 12 | 0 | 0 | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan |
| long_3d | xgboost | future | F1 | None | a9bc356b2456de900a7f2654719200b7ac433a3918295bf76926551af7a90541 | baseline | raw | clean_targets_inputs | 12 | 0 | 0 | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan |
