# 실험 20261004T105046_KST_peak_alarm_diagnostic_paired_weighted_weighted_medium_8h_xgboost_observed_F2_w0_9abe7799f3

- 상태: 완료
- 목적과 가설: 동일 파라미터/F/입력 창의 무가중 후보와 비교하여 cap2 연속·확률 연계 가중 제곱오차 학습의 절충을 확인한다. 평가 cap은모두2다.
- 시작·종료 시각 및 시간대: 2026-10-04T10:50:48.498614+09:00 / 2026-10-04T10:50:50.039868+09:00, Asia/Seoul.
- 모델·라이브러리 버전: xgboost, Python=3.13.5, {'numpy': '2.1.3', 'pandas': '2.2.3', 'scikit-learn': '1.6.1', 'xgboost': '3.4.1', 'lightgbm': '4.7.0', 'catboost': '1.2.10', 'joblib': '1.4.2', 'nbclient': '0.10.2'}.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv, SHA256=0173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7; 완료 fold=['sep'].
- 목표값·단위·예측 구간: power_15min kW, medium_8h, H=3215분 셀.
- 학습·검증·테스트 분할과 누수 점검: 4~8월 expanding, train 전체H끝<월시작, valid 전체H끝<월끝. sample weights의 p_ref는 그 학습 원점 당시 이전 월 데이터만 학습한 무가중 RF OOF. 현 검증월·9월 예측을 학습 가중치에 쓰지 않는다. Jan/OOF 월경계 gaps는 w1.
- 전처리·특성·하이퍼파라미터·seed: F2, observed, context=None, {'objective': 'reg:squarederror', 'eval_metric': 'rmse', 'tree_method': 'hist', 'booster': 'gbtree', 'n_estimators': 150, 'learning_rate': 0.05, 'max_depth': 4, 'min_child_weight': 5, 'reg_lambda': 5, 'reg_alpha': 0, 'gamma': 0, 'subsample': 0.9, 'colsample_bytree': 0.8, 'random_state': 42, 'n_jobs': 4}; seed42. 학습 cell w=1+(2-1)*g(y,B)*(1+p_ref)/2. RF native4는 원점 평균 w, scalar direct/pooled는 해당 lead w. 미래 target은 학습 가중치 계산용 정답이며 예측 입력이 아니다.
- 이전 또는 기준 실험 링크와 변경 사항: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\experiments\xgboost\20261004T040425_KST_cffc42_loss_c_fivefold_medium_8h_xgboost_observed_F2_w0_c20cc06d25.md; 해당 기준 후보에서 sample_weight만 바꾸고 파라미터를 다시 탐색하지 않는다. 미래 외생 오차0 기준 교사 확률을 쓰는 탐색 조건을 보존한다.
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: .venv_boosting/Scripts/python.exe -B -X utf8 notebooks/_shared/weighted_tree_fivefold.py; codeSHA256=acf57fb38b8d94aaf9b8b1943e83364cec8746459f6053f44b271e894448c83d.
- 실제 실행 시간·자원 사용량(측정한 경우): 1.536s; 새fit=1; CPU4threads; fold경계RSS=236.2MiB, 실제peak 미측정.
- 평가 지표·구간별 또는 fold별 결과: 아래표는 기본 w1 지표. 확정 공통 p_ref/cap2 C는 probability_linked_fold_metrics.csv와 아래 평가 이력에 별도 저장한다. 대표 선택은 같은 공통 C의5개월 동일가중 평균이다.
- 기준모델 대비 변화와 비교 가능 여부: 동일 분할/원점/입력/파라미터, sample weight만 변경. 이 학습은 weighted squared error이며 과소오차/CVaR/복합 C를 직접 최적화하지 않는다.
- 오차가 큰 조건·해석·한계: 가중치를 적용하면 과소/과대 절충이 생길 수 있어 RMSE와 고부하 양방향 오차를 같이 보고한다. 이전 무가중 선정 후보만 재가중하므로 가중 모델의 전역 최적 파라미터 탐색이 아니다. global q90와 이전9월 노출로 탐색 평가.
- 오류·경고·실패 또는 중단 원인: 없음; [].
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\performance\runs\20261004T105046_KST_peak_alarm_diagnostic\20261004T105046_KST_peak_alarm_diagnostic_paired_weighted\weighted_points\medium_8h\xgboost\observed_F2_w0_9abe7799f3; 모델/예측/특성/학습원점/가중치/OOF출처/지표/상태.
- 결론과 다음 실험: 완료5-fold 후보만 무가중 풀에 추가해 비교하고, 최종 선택을 동결한 후9월을 재평가한다.

| Loss_A | MAE | L_mean | L_CVaR | L_peak | Loss_B | Loss_C | tail_windows | n_origins | n_predictions | n_risk_windows | fold | n_train | n_train_scalar_rows | n_oof_supported |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 11.1610 | 8.1501 | 9.1820 | 18.6204 | 7.6105 | 12.9574 | 11.6992 | 527 | 329 | 10528 | 2632 | sep | 5487 | 54870 | 5032 |


## 참조 채팅 확정: 공통 확률 연계 C

- 기준: q90=170 시작, 월중 관측최대 갱신, 발행 경로 B 고정. w=1+(cap-1)*g(actual,B)*(1+p_ref)/2.
- 모든 후보의 대표 선택에는 cap2를 공통 적용. p_ref는 동일한 무가중 native RF/F2/미래 외생 오차0 참조 모델의 해당 월 OOF raw 확률이며, 후보 자기 확률을 쓰지 않는다.
- 관측 외생 후보의 점 예측 입력에는 미래 외생을 넣지 않는다. 공통 위험 평가 가중치의 참조 확률은 미래 외생 오차0 조건으로 만들어진 탐색용 평가 계약이며, 관측 전용 운용 위험 가중치로 검증된 것은 아니다.
- 참조 fold 이벤트·원점·H·확률 범위·기간 확률 관계 및 전체 경로 학습 경계를 감사했다. pure 접근도 C는 위의 민감도 표에 보존하되 최종 대표 선정은 아래 확률 연계 공통 C를 사용한다.

| fold | cap | Loss_A | MAE | L_mean | L_CVaR | L_peak | Loss_B | Loss_C | tail_windows | n_predictions | n_risk_windows | n_origins | n_high_cells | high_under_RMSE | high_over_RMSE | path_max_under_RMSE | path_max_MAE | path_peak_time_MAE_minutes | path_peak_time_bias_minutes | n_peak_timing_paths | n_paths_max_tie_actual | n_paths_max_tie_predicted | peak_timing_tie_policy | n_peak_event_paths | event_peak_time_MAE_minutes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| sep | 1.0000 | 11.1610 | 8.1501 | 9.1820 | 18.6204 | 7.6105 | 12.9574 | 11.6992 | 527 | 10528 | 2632 | 329 | 2301 | 12.7119 | 3.1192 | 15.8001 | 13.9160 | 84.0729 | -33.1915 | 329 | 58 | 260 | earliest | 16 | 32.8125 |
| sep | 2.0000 | 11.1610 | 8.1501 | 9.1820 | 18.6204 | 8.3672 | 12.9574 | 11.8506 | 527 | 10528 | 2632 | 329 | 2301 | 12.7119 | 3.1192 | 15.8001 | 13.9160 | 84.0729 | -33.1915 | 329 | 58 | 260 | earliest | 16 | 32.8125 |
| sep | 4.0000 | 11.1610 | 8.1501 | 9.1820 | 18.6204 | 9.7052 | 12.9574 | 12.1182 | 527 | 10528 | 2632 | 329 | 2301 | 12.7119 | 3.1192 | 15.8001 | 13.9160 | 84.0729 | -33.1915 | 329 | 58 | 260 | earliest | 16 | 32.8125 |

- 초기 실행 코드 식별 보강: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\performance\runs\20261004T040425_KST_cffc42_loss_c_fivefold\worker_runtime_snapshot.json (실행 시작 시 snapshot). 실행 중 읽은 디스크 hash와 로드된 소스를 구분하며 학습 API 원본은 유지했다.


## 가중/무가중 완전 대응 진단

- 실제 학습1~8월, 전체H끝<9/1. 기존 무가중 대표모델과 동일 params/F/window/seed, 학습 가중치만 cap2로 적용.
- 실행 명령: .venv_boosting/Scripts/python.exe -X utf8 notebooks/evaluation/run_peak_alarm_diagnostic.py --paired; driverSHA256=6bd7b7e1952110b3cf9244733a81ba8a864878c5b16c749a172c652488196690.
- cap2는 기존 설계와 완료된 개발CV 비교의 사전 고정 대조군. 9월 결과로 파라미터·가중치·모델 재선정하지 않음.
