# 실험 20261004T104539_KST_peak_alarm_diagnostic_warning_medium_4h_future

- 상태: 완료
- 목적과 가설: 학습 피크 가중치 유무 × 과거 OOF P95 안전마진 유무. 같은 설정의 경보 포착/오경보 비교.
- 시작·종료 시각 및 시간대: 2026-10-04T10:48:33.824198+09:00 / 2026-10-04T10:48:34.244493+09:00, Asia/Seoul.
- 모델·라이브러리 버전: xgboost; {'numpy': '2.1.3', 'pandas': '2.2.3', 'scikit-learn': '1.6.1', 'xgboost': '3.4.1', 'lightgbm': '4.7.0', 'catboost': '1.2.10', 'joblib': '1.4.2', 'nbclient': '0.10.2'}; 새 경보 모델 fit=0, 기존/대조군 모델 출력 사용.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv; SHA256=0173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7; OOF 4~8월, 평가9월1~14일 완전 경로.
- 목표값·단위·예측 구간: power_15min kW; medium_4h; 실제 사건은 발행시 B를 넘는 미래 max.
- 학습·검증·테스트 분할과 누수 점검: OOF의 각 학습 전체 H끝<검증 시작, OOF 라벨 끝<9/1 검증. P95에9월 오차 미사용. 최종 점 모델1~8월 학습. 알려진9월 재평가.
- 전처리·특성·하이퍼파라미터·seed: F2, future, window=None; {'objective': 'reg:squarederror', 'eval_metric': 'rmse', 'tree_method': 'hist', 'booster': 'gbtree', 'n_estimators': 150, 'learning_rate': 0.05, 'max_depth': 4, 'min_child_weight': 5, 'reg_lambda': 5, 'reg_alpha': 0, 'gamma': 0, 'subsample': 0.9, 'colsample_bytree': 0.8, 'random_state': 42, 'n_jobs': 4}; seed42. P95는 np.quantile linear, 전체 OOF 원점 풀링, lead별.
- 이전 또는 기준 실험 링크와 변경 사항: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\experiments\xgboost\20261004T040425_KST_cffc42_loss_c_fivefold_weighted_medium_4h_xgboost_future_F2_w0_05d8732be0.md; 대조군=C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\experiments\xgboost\20261004T040425_KST_cffc42_loss_c_fivefold_final_points_medium_4h_xgboost_future_F2_w0_5c11bb38ab.md; 원본 선정·보고서 불변. weighted=reference_linked_cap2; 평가 cap1/2는 모두 동일.
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: .venv_boosting/Scripts/python.exe -X utf8 notebooks/evaluation/run_peak_alarm_diagnostic.py; driverSHA256=879a94250cc221e05e78069392884f2ab237d674ce85ea1ce912f053eaee8194; helperSHA256=034e3d8a22bb4f0a7cebb426c4970411b116ad44908fa66b4b8d6ed0a79663d1.
- 실제 실행 시간·자원 사용량(측정한 경우): 경보 fit=0, 재평가 개별 시간/RSS 미측정; 새 전력 적합은 별도 모델 기록 참조.
- 평가 지표·구간별 또는 fold별 결과: 아래 표. full/clean_targets/clean_targets_inputs 구분. TP/FN은 중첩된 발행 원점 수, 실제 사건일은 별도 CSV.
- 기준모델 대비 변화와 비교 가능 여부: 동일 원점·목표·B·예측구간·평가식. 원래 무가중이면 가중 대조군 미실행으로 명시.
- 오차가 큰 조건·해석·한계: 경험적 lead별 P95이며 동시 경로95% 보장 아님. 검증기간으로 후보도 선택되어 nested calibration 아님. 월별 분포·중첩·소표본·알려진9월의 한계. 생산조건별 P95 미구현. 안전마진은 조기경고이며 피크확률이 아님.
- 오류·경고·실패 또는 중단 원인: 없음; key/실제값/원점/B 고정/최종선정 해시 검증.
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\reports\20261004T104539_KST_peak_alarm_diagnostic; 개별예측은 기존/대조군artifact; 수정 없음.
- 결론과 다음 실험: 아래 실제 수치로 가중치 효과와 마진 효과를 분리. 운영 채택·임계값 선택은 새 독립 구간에서 재검증 필요.

| profile | scenario_key | model | feature_set | weighting | scope | evaluation_cap | Loss_A | MAE | L_mean | L_CVaR | L_peak | Loss_B | Loss_C | tail_windows | n_predictions | n_risk_windows | n_origins | n_high_cells | high_under_RMSE | high_over_RMSE | path_max_under_RMSE | path_max_MAE | path_peak_time_MAE_minutes | path_peak_time_bias_minutes | n_peak_timing_paths | n_paths_max_tie_actual | n_paths_max_tie_predicted | peak_timing_tie_policy | n_peak_event_paths | event_peak_time_MAE_minutes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| medium_4h | future | xgboost | F2 | weighted | full | 1.0000 | 11.5402 | 8.1276 | 9.2391 | 19.6798 | 7.9006 | 13.4154 | 12.1036 | 267 | 5328 | 1332 | 333 | 1150 | 12.7809 | 4.1656 | 13.2262 | 10.6776 | 61.2613 | -20.0901 | 333 | 53 | 259 | earliest | 8 | 33.7500 |
| medium_4h | future | xgboost | F2 | weighted | full | 2.0000 | 11.5402 | 8.1276 | 9.2391 | 19.6798 | 8.5877 | 13.4154 | 12.2410 | 267 | 5328 | 1332 | 333 | 1150 | 12.7809 | 4.1656 | 13.2262 | 10.6776 | 61.2613 | -20.0901 | 333 | 53 | 259 | earliest | 8 | 33.7500 |
| medium_4h | future | xgboost | F2 | weighted | clean_targets | 1.0000 | 11.1774 | 7.9897 | 9.0499 | 19.0233 | 7.9392 | 13.0393 | 11.8198 | 264 | 5264 | 1316 | 329 | 1122 | 12.9131 | 4.0648 | 13.2716 | 10.7069 | 61.0486 | -19.3769 | 329 | 53 | 255 | earliest | 8 | 33.7500 |
| medium_4h | future | xgboost | F2 | weighted | clean_targets | 2.0000 | 11.1774 | 7.9897 | 9.0499 | 19.0233 | 8.6290 | 13.0393 | 11.9578 | 264 | 5264 | 1316 | 329 | 1122 | 12.9131 | 4.0648 | 13.2716 | 10.7069 | 61.0486 | -19.3769 | 329 | 53 | 255 | earliest | 8 | 33.7500 |
| medium_4h | future | xgboost | F2 | unweighted | full | 1.0000 | 11.9704 | 8.3053 | 9.4024 | 20.5138 | 8.5368 | 13.8470 | 12.5627 | 267 | 5328 | 1332 | 333 | 1150 | 14.4577 | 3.4117 | 14.2039 | 11.5175 | 63.8739 | -14.8649 | 333 | 53 | 245 | earliest | 8 | 28.1250 |
| medium_4h | future | xgboost | F2 | unweighted | full | 2.0000 | 11.9704 | 8.3053 | 9.4024 | 20.5138 | 9.3434 | 13.8470 | 12.7240 | 267 | 5328 | 1332 | 333 | 1150 | 14.4577 | 3.4117 | 14.2039 | 11.5175 | 63.8739 | -14.8649 | 333 | 53 | 245 | earliest | 8 | 28.1250 |
| medium_4h | future | xgboost | F2 | unweighted | clean_targets | 1.0000 | 11.6594 | 8.1825 | 9.2291 | 19.9466 | 8.5756 | 13.5161 | 12.3136 | 264 | 5264 | 1316 | 329 | 1122 | 14.6043 | 3.3244 | 14.2454 | 11.5544 | 63.7386 | -14.1337 | 329 | 53 | 241 | earliest | 8 | 28.1250 |
| medium_4h | future | xgboost | F2 | unweighted | clean_targets | 2.0000 | 11.6594 | 8.1825 | 9.2291 | 19.9466 | 9.3854 | 13.5161 | 12.4756 | 264 | 5264 | 1316 | 329 | 1122 | 14.6043 | 3.3244 | 14.2454 | 11.5544 | 63.7386 | -14.1337 | 329 | 53 | 241 | earliest | 8 | 28.1250 |

| profile | scenario_key | model | weighting | policy | scope | margin_min | margin_max | n_origins | n_positive | TP | FP | FN | TN | recall | precision | false_positive_rate | alarm_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| medium_4h | future | xgboost | weighted | no_margin | full | 0.0000 | 0.0000 | 333 | 8 | 4 | 0 | 4 | 325 | 0.5000 | 1.0000 | 0.0000 | 0.0120 |
| medium_4h | future | xgboost | weighted | no_margin | clean_targets | 0.0000 | 0.0000 | 329 | 8 | 4 | 0 | 4 | 321 | 0.5000 | 1.0000 | 0.0000 | 0.0122 |
| medium_4h | future | xgboost | weighted | P95_margin | full | 0.1019 | 0.1420 | 333 | 8 | 7 | 62 | 1 | 263 | 0.8750 | 0.1014 | 0.1908 | 0.2072 |
| medium_4h | future | xgboost | weighted | P95_margin | clean_targets | 0.1019 | 0.1420 | 329 | 8 | 7 | 59 | 1 | 262 | 0.8750 | 0.1061 | 0.1838 | 0.2006 |
| medium_4h | future | xgboost | unweighted | no_margin | full | 0.0000 | 0.0000 | 333 | 8 | 0 | 0 | 8 | 325 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_4h | future | xgboost | unweighted | no_margin | clean_targets | 0.0000 | 0.0000 | 329 | 8 | 0 | 0 | 8 | 321 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_4h | future | xgboost | unweighted | P95_margin | full | 0.1020 | 0.1450 | 333 | 8 | 6 | 41 | 2 | 284 | 0.7500 | 0.1277 | 0.1262 | 0.1411 |
| medium_4h | future | xgboost | unweighted | P95_margin | clean_targets | 0.1020 | 0.1450 | 329 | 8 | 6 | 39 | 2 | 282 | 0.7500 | 0.1333 | 0.1215 | 0.1368 |
