# 실험 20261004T040425_KST_cffc42_loss_c_fivefold_peak_event_medium_12h_xgboost_future_F3_w0_small_93e177d8

- 상태: 완료
- 목적과 가설: 미래 전체 경로의 최대전력이 원점 기준 B를 초과할 확률을 직접 이진 분류한다. 확률 보정 여부는 같은 5-fold Brier로 비교한다.
- 시작·종료 시각 및 시간대: 2026-10-04T05:52:58.855382+09:00 / 2026-10-04T05:53:07.029309+09:00, Asia/Seoul.
- 모델·라이브러리 버전: xgboost classifier; {'numpy': '2.1.3', 'pandas': '2.2.3', 'scikit-learn': '1.6.1', 'xgboost': '3.4.1', 'lightgbm': '4.7.0', 'catboost': '1.2.10', 'joblib': '1.4.2', 'nbclient': '0.10.2'}; interpreter=C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\.venv_boosting\Scripts\python.exe.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv, SHA256=0173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7; 완료 fold=['apr', 'may', 'jun', 'jul', 'aug']; q90=170은 전체 기간에서 계산했다.
- 목표값·단위·예측 구간: max_h power_15min > B(origin)의 이진 사건, power kW, probability 0~1; medium_12h.
- 학습·검증·테스트 분할과 누수 점검: 4~8월 expanding 5-fold; 각 fold 이전 보정 창=previous_month. base 학습의 전체 H 끝<보정시작, 보정 전체H끝<검증월시작. 미래 power 중간입력 없음. 9월 선택 사용 없음.
- 전처리·특성·하이퍼파라미터·seed: F3, context=None, future, small, {'objective': 'binary:logistic', 'eval_metric': 'logloss', 'tree_method': 'hist', 'n_estimators': 120, 'max_depth': 3, 'learning_rate': 0.05, 'min_child_weight': 10, 'reg_lambda': 10, 'subsample': 0.9, 'colsample_bytree': 0.9, 'random_state': 42, 'n_jobs': 2}; seed42; origin 요약 입력과 알려진 B를 추가. 클래스 재가중·복제 없음.
- 이전 또는 기준 실험 링크와 변경 사항: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\experiments\xgboost\20261003T182425_KST_e84d50_performance_medium_12h_xgboost_future_F3_pooled.md; 구간 사건 경험 빈도 기준선, raw/monotone sigmoid 보정 비교. 점 모델과 분류 모델의 목적이 다르다.
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: .venv_boosting/Scripts/python.exe -B -X utf8 notebooks/_shared/peak_event_fivefold.py --stage cv; SHA256=e49160b8a12e975151394c958e00f9c59a88a79d578c6e4de84302de4ec26516.
- 실제 실행 시간·자원 사용량(측정한 경우): 8.168s; base fit=5, 보정 fit=5; CPU2threads; fold경계 RSS=497.5MiB, 실제 peak 미측정.
- 평가 지표·구간별 또는 fold별 결과: 아래 표. Brier 주지표, log loss 보조. 두 클래스가 없는 AUROC/AP는 미측정. 경보0.5는 진단이고 최적 운영 임계값이 아니다.
- 기준모델 대비 변화와 비교 가능 여부: 동일 origin/B/path 사건의 사전 학습 경험 빈도와 비교. 5월 평균과 9월은 별도다.
- 오차가 큰 조건·해석·한계: 장기 월별27~28경로, 경로 중첩. F1에도 사건 정의에 필요한 B(관측 전력 기반)를 입력하여 point F1과 정보 계약이 다르다. 미래 외생은 실측 대체 오차0 가정. 전체 q90와 이미 본9월로 인해 탐색 평가.
- 오류·경고·실패 또는 중단 원인: 없음; [].
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\performance\runs\20261004T040425_KST_cffc42_loss_c_fivefold\peak_event\medium_12h\xgboost\future_F3_w0_small_93e177d8; probabilities, fit/calibration origins, model/calibrator joblib, features, reliability CSV, config/state/metrics.
- 결론과 다음 실험: 완료5fold만 비교하고 raw/calibration/모델/F 선택을9월전에 동결한다. 단일 클래스 fit은 Jeffreys 상수확률로 기록한다.

| n_origins | n_positive | event_rate | Brier | LogLoss | AUROC | AP | mean_probability | recall_at_05 | precision_at_05 | true_positive | false_positive | false_negative | fold | method | n_fit | n_calibration | n_fit_positive | n_calibration_positive | base_single_class | n_features | fit_save_seconds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 708 | 21 | 0.0297 | 0.0325 | 0.1509 | 0.5886 | 0.0584 | 0.0378 | 0.0000 | 0.0000 | 0 | 6 | 21 | apr | raw | 1067 | 732 | 45 | 45 | False | 109 | 0.3353 |
| 708 | 21 | 0.0297 | 0.0327 | 0.1483 | 0.5886 | 0.0584 | 0.0554 | 0.0000 | 0.0000 | 0 | 3 | 21 | apr | calibrated | 1067 | 732 | 45 | 45 | False | 109 | 0.3434 |
| 708 | 21 | 0.0297 | 0.0292 | 0.1386 | 0.5000 | 0.0297 | 0.0499 | 0.0000 | nan | 0 | 0 | 21 | apr | baseline | 1067 | 732 | 45 | 45 | False | 109 | 0.3502 |
| 732 | 24 | 0.0328 | 0.0535 | 0.1742 | 0.8267 | 0.0893 | 0.0668 | 0.0000 | 0.0000 | 0 | 27 | 24 | may | raw | 1811 | 708 | 90 | 21 | False | 109 | 0.3538 |
| 732 | 24 | 0.0328 | 0.0313 | 0.1334 | 0.8267 | 0.0893 | 0.0309 | 0.0000 | nan | 0 | 0 | 24 | may | calibrated | 1811 | 708 | 90 | 21 | False | 109 | 0.3581 |
| 732 | 24 | 0.0328 | 0.0318 | 0.1459 | 0.5000 | 0.0328 | 0.0440 | 0.0000 | nan | 0 | 0 | 24 | may | baseline | 1811 | 708 | 90 | 21 | False | 109 | 0.3678 |
| 708 | 45 | 0.0636 | 0.0342 | 0.1160 | 0.9815 | 0.8224 | 0.0543 | 0.0889 | 1.0000 | 4 | 0 | 41 | jun | raw | 2531 | 732 | 111 | 24 | False | 109 | 0.4764 |
| 708 | 45 | 0.0636 | 0.0336 | 0.1079 | 0.9815 | 0.8224 | 0.0428 | 0.1111 | 1.0000 | 5 | 0 | 40 | jun | calibrated | 2531 | 732 | 111 | 24 | False | 109 | 0.4850 |
| 708 | 45 | 0.0636 | 0.0600 | 0.2420 | 0.5000 | 0.0636 | 0.0414 | 0.0000 | nan | 0 | 0 | 45 | jun | baseline | 2531 | 732 | 111 | 24 | False | 109 | 0.4927 |
| 732 | 27 | 0.0369 | 0.0337 | 0.1350 | 0.8287 | 0.1724 | 0.0244 | 0.0000 | nan | 0 | 0 | 27 | jul | raw | 3275 | 708 | 135 | 45 | False | 109 | 0.5986 |
| 732 | 27 | 0.0369 | 0.0408 | 0.1510 | 0.8287 | 0.1724 | 0.0541 | 0.1481 | 0.1667 | 4 | 20 | 23 | jul | calibrated | 3275 | 708 | 135 | 45 | False | 109 | 0.6053 |
| 732 | 27 | 0.0369 | 0.0356 | 0.1588 | 0.5000 | 0.0369 | 0.0452 | 0.0000 | nan | 0 | 0 | 27 | jul | baseline | 3275 | 708 | 135 | 45 | False | 109 | 0.6131 |
| 732 | 24 | 0.0328 | 0.0824 | 0.2768 | 0.5675 | 0.0413 | 0.1163 | 0.0000 | 0.0000 | 0 | 69 | 24 | aug | raw | 3995 | 732 | 180 | 27 | False | 109 | 0.6949 |
| 732 | 24 | 0.0328 | 0.0411 | 0.1778 | 0.5675 | 0.0413 | 0.0659 | 0.0000 | nan | 0 | 0 | 24 | aug | calibrated | 3995 | 732 | 180 | 27 | False | 109 | 0.7024 |
| 732 | 24 | 0.0328 | 0.0318 | 0.1459 | 0.5000 | 0.0328 | 0.0438 | 0.0000 | nan | 0 | 0 | 24 | aug | baseline | 3995 | 732 | 180 | 27 | False | 109 | 0.7095 |
