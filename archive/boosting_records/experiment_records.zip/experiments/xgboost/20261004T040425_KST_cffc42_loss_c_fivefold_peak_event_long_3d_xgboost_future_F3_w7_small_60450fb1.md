# 실험 20261004T040425_KST_cffc42_loss_c_fivefold_peak_event_long_3d_xgboost_future_F3_w7_small_60450fb1

- 상태: 완료
- 목적과 가설: 미래 전체 경로의 최대전력이 원점 기준 B를 초과할 확률을 직접 이진 분류한다. 확률 보정 여부는 같은 5-fold Brier로 비교한다.
- 시작·종료 시각 및 시간대: 2026-10-04T06:22:38.990352+09:00 / 2026-10-04T06:22:43.026872+09:00, Asia/Seoul.
- 모델·라이브러리 버전: xgboost classifier; {'numpy': '2.1.3', 'pandas': '2.2.3', 'scikit-learn': '1.6.1', 'xgboost': '3.4.1', 'lightgbm': '4.7.0', 'catboost': '1.2.10', 'joblib': '1.4.2', 'nbclient': '0.10.2'}; interpreter=C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\.venv_boosting\Scripts\python.exe.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv, SHA256=0173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7; 완료 fold=['apr', 'may', 'jun', 'jul', 'aug']; q90=170은 전체 기간에서 계산했다.
- 목표값·단위·예측 구간: max_h power_15min > B(origin)의 이진 사건, power kW, probability 0~1; long_3d.
- 학습·검증·테스트 분할과 누수 점검: 4~8월 expanding 5-fold; 각 fold 이전 보정 창=28d. base 학습의 전체 H 끝<보정시작, 보정 전체H끝<검증월시작. 미래 power 중간입력 없음. 9월 선택 사용 없음.
- 전처리·특성·하이퍼파라미터·seed: F3, context=7, future, small, {'objective': 'binary:logistic', 'eval_metric': 'logloss', 'tree_method': 'hist', 'n_estimators': 120, 'max_depth': 3, 'learning_rate': 0.05, 'min_child_weight': 10, 'reg_lambda': 10, 'subsample': 0.9, 'colsample_bytree': 0.9, 'random_state': 42, 'n_jobs': 2}; seed42; origin 요약 입력과 알려진 B를 추가. 클래스 재가중·복제 없음.
- 이전 또는 기준 실험 링크와 변경 사항: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\experiments\xgboost\20261004T040425_KST_cffc42_loss_c_fivefold_long_3d_xgboost_future_F3_w7_ef3a7eb415.md; 구간 사건 경험 빈도 기준선, raw/monotone sigmoid 보정 비교. 점 모델과 분류 모델의 목적이 다르다.
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: .venv_boosting/Scripts/python.exe -B -X utf8 notebooks/_shared/peak_event_fivefold.py --stage cv; SHA256=0ab5153adb44d91e509e63a1d337fe0eaeabc9a62cb43077d462a85c92895626.
- 실제 실행 시간·자원 사용량(측정한 경우): 4.028s; base fit=5, 보정 fit=5; CPU2threads; fold경계 RSS=239.8MiB, 실제 peak 미측정.
- 평가 지표·구간별 또는 fold별 결과: 아래 표. Brier 주지표, log loss 보조. 두 클래스가 없는 AUROC/AP는 미측정. 경보0.5는 진단이고 최적 운영 임계값이 아니다.
- 기준모델 대비 변화와 비교 가능 여부: 동일 origin/B/path 사건의 사전 학습 경험 빈도와 비교. 5월 평균과 9월은 별도다.
- 오차가 큰 조건·해석·한계: 장기 월별27~28경로, 경로 중첩. F1에도 사건 정의에 필요한 B(관측 전력 기반)를 입력하여 point F1과 정보 계약이 다르다. 미래 외생은 실측 대체 오차0 가정. 전체 q90와 이미 본9월로 인해 탐색 평가.
- 오류·경고·실패 또는 중단 원인: 없음; [].
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\performance\runs\20261004T040425_KST_cffc42_loss_c_fivefold\peak_event\long_3d\xgboost\future_F3_w7_small_60450fb1; probabilities, fit/calibration origins, model/calibrator joblib, features, reliability CSV, config/state/metrics.
- 결론과 다음 실험: 완료5fold만 비교하고 raw/calibration/모델/F 선택을9월전에 동결한다. 단일 클래스 fit은 Jeffreys 상수확률로 기록한다.

| n_origins | n_positive | event_rate | Brier | LogLoss | AUROC | AP | mean_probability | recall_at_05 | precision_at_05 | true_positive | false_positive | false_negative | fold | method | n_fit | n_calibration | n_fit_positive | n_calibration_positive | base_single_class | n_features | fit_save_seconds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 27 | 4 | 0.1481 | 0.1265 | 0.4207 | 0.5000 | 0.1481 | 0.1315 | 0.0000 | nan | 0 | 0 | 4 | apr | raw | 30 | 25 | 4 | 8 | False | 129 | 0.3022 |
| 27 | 4 | 0.1481 | 0.1557 | 0.4973 | 0.5000 | 0.1481 | 0.3200 | 0.0000 | nan | 0 | 0 | 4 | apr | calibrated | 30 | 25 | 4 | 8 | False | 129 | 0.3076 |
| 27 | 4 | 0.1481 | 0.1327 | 0.4398 | 0.5000 | 0.1481 | 0.2288 | 0.0000 | nan | 0 | 0 | 4 | apr | baseline | 30 | 25 | 4 | 8 | False | 129 | 0.3129 |
| 28 | 6 | 0.2143 | 0.1687 | 0.5206 | 0.5000 | 0.2143 | 0.2333 | 0.0000 | nan | 0 | 0 | 6 | may | raw | 60 | 25 | 14 | 3 | False | 129 | 0.1910 |
| 28 | 6 | 0.2143 | 0.1773 | 0.5548 | 0.5000 | 0.2143 | 0.1200 | 0.0000 | nan | 0 | 0 | 6 | may | calibrated | 60 | 25 | 14 | 3 | False | 129 | 0.1968 |
| 28 | 6 | 0.2143 | 0.1684 | 0.5197 | 0.5000 | 0.2143 | 0.2079 | 0.0000 | nan | 0 | 0 | 6 | may | baseline | 60 | 25 | 14 | 3 | False | 129 | 0.2182 |
| 27 | 8 | 0.2963 | 0.2180 | 0.6347 | 0.5000 | 0.2963 | 0.1986 | 0.0000 | nan | 0 | 0 | 8 | jun | raw | 91 | 25 | 18 | 3 | False | 129 | 0.2395 |
| 27 | 8 | 0.2963 | 0.2396 | 0.7182 | 0.5000 | 0.2963 | 0.1200 | 0.0000 | nan | 0 | 0 | 8 | jun | calibrated | 91 | 25 | 18 | 3 | False | 129 | 0.2454 |
| 27 | 8 | 0.2963 | 0.2170 | 0.6315 | 0.5000 | 0.2963 | 0.2042 | 0.0000 | nan | 0 | 0 | 8 | jun | baseline | 91 | 25 | 18 | 3 | False | 129 | 0.2510 |
| 28 | 4 | 0.1429 | 0.1257 | 0.4211 | 0.5000 | 0.1429 | 0.1997 | 0.0000 | nan | 0 | 0 | 4 | jul | raw | 121 | 25 | 24 | 7 | False | 129 | 0.1914 |
| 28 | 4 | 0.1429 | 0.1413 | 0.4634 | 0.5000 | 0.1429 | 0.2800 | 0.0000 | nan | 0 | 0 | 4 | jul | calibrated | 121 | 25 | 24 | 7 | False | 129 | 0.1960 |
| 28 | 4 | 0.1429 | 0.1279 | 0.4278 | 0.5000 | 0.1429 | 0.2167 | 0.0000 | nan | 0 | 0 | 4 | jul | baseline | 121 | 25 | 24 | 7 | False | 129 | 0.2027 |
| 28 | 5 | 0.1786 | 0.1887 | 0.5661 | 0.4696 | 0.2394 | 0.2761 | 0.0000 | 0.0000 | 0 | 4 | 5 | aug | raw | 152 | 25 | 34 | 3 | False | 129 | 0.2612 |
| 28 | 5 | 0.1786 | 0.1565 | 0.5070 | 0.4696 | 0.2394 | 0.1483 | 0.0000 | nan | 0 | 0 | 5 | aug | calibrated | 152 | 25 | 34 | 3 | False | 129 | 0.2675 |
| 28 | 5 | 0.1786 | 0.1478 | 0.4728 | 0.5000 | 0.1786 | 0.2127 | 0.0000 | nan | 0 | 0 | 5 | aug | baseline | 152 | 25 | 34 | 3 | False | 129 | 0.2732 |
