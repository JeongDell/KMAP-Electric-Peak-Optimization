# 실험 20261003T201248_KST_0f606b_august_frozen_long_3d_xgboost_future_F3_selected

- 상태: 완료
- 목적과 가설: 4~7월 선정 설정의 8월 추가 확인. F·params·seed·혼합 가중치를 8월 점수로 재선정하지 않는다.
- 시작·종료 시각 및 시간대: 2026-10-03T20:30:35.745654+09:00 / 2026-10-03T20:30:37.280349+09:00, Asia/Seoul.
- 모델·라이브러리 버전: xgboost; Python 3.13.5; {'numpy': '2.1.3', 'pandas': '2.2.3', 'scikit-learn': '1.6.1', 'xgboost': '3.4.1', 'lightgbm': '4.7.0', 'catboost': '1.2.10', 'joblib': '1.4.2', 'nbclient': '0.10.2'}.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv; SHA256 0173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7. 1~8월, 종료시각<2021-09-01. 보정 대조 C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\timeseries_all.csv; SHA256 757979cf6e85d962b2fd3900bf45b4c8c1036d22a1cb9063e6f573af28fb1ce4. 원본 변경 없음.
- 목표값·단위·예측 구간: power_15min(kW), long_3d, H=288개 15분 원경로, 갱신 1440분. 시간평균도 kW이며 kWh가 아니다.
- 학습·검증·테스트 분할과 누수 점검: 학습 전체 H 정답 끝<8/1, 8월 원점>=8/1·전체 H 정답 끝<9/1. 9월은 수치 검사·특성 생성 전에 제외. 월내 모델 고정. 단기7d/장기14d F3 지원을 모든 모델과 외생조건에 공통 적용. 미래 전력 중간 입력 없음.
- 전처리·특성·하이퍼파라미터·seed: F3, future_actual_as_forecast_zero_error; {'objective': 'reg:squarederror', 'eval_metric': 'rmse', 'tree_method': 'hist', 'booster': 'gbtree', 'n_estimators': 150, 'learning_rate': 0.05, 'max_depth': 4, 'min_child_weight': 5, 'reg_lambda': 5, 'reg_alpha': 0, 'gamma': 0, 'subsample': 0.9, 'colsample_bytree': 0.8, 'random_state': 42, 'n_jobs': 4}; seed42. 단기 RF native4출력/부스팅4독립horizon, 중장기 pooled horizon. pooled 원점별 동일 개수·무복원·최대60000행, 평가 전체 경로. 같은 profile의 훈련키·정답 동일.
- 이전 또는 기준 실험 링크와 변경 사항: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\experiments\xgboost\20261003T182425_KST_e84d50_performance_long_3d_xgboost_future_F3_pooled.md. 변경은 1~7월 학습과 8월 평가 기간만. 기존 결과 보존.
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: .venv_boosting/Scripts/python.exe -B notebooks/_shared/august_performance.py; C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\.venv_boosting\Scripts\python.exe; code SHA256 {'august_performance.py': '4cf87a7444db963f258e4e83168799adf4b82a47015d2468ed55ad0051d83091', 'performance_train.py': '6f8fc5d2fccaa21cb300a0fa327af74c52c5c50060b778b28a4c16909843c203', 'performance_profiles.py': 'e4d6c0eae7a2bf643ce30b40158d5b27f04d28da331ba2220edbeca8119c9b43', 'boosting_common.py': 'a9c8dd42417219e67dd6b7a8327b74ba4a8172d368ce19a8292d7025421d19e4', 'rf_current_data.py': '70b983520a4cfcee6551953f29e9466c083608244fdf05503cd4ca93b62f7fa4', 'forecast_common.py': '4093c76a243c18181a958d67e6137c3e891a26236ba71d9d48e29331fc91ce15', 'rf_august_confirmation.py': 'e78e393707985e4d1bfd8c092bca96bb2694a6347e072daa3a0a4f8979f334a2'}; Git 없는 workspace.
- 실제 실행 시간·자원 사용량(측정한 경우): 1.518s, 새 fit 1회, CPU4threads, 마지막 fit 직후·예측 종료 관측 RSS 중 큰 값 414.5MiB(실행 중 최대 메모리 미측정).
- 평가 지표·구간별 또는 fold별 결과: 아래 8월 scope별 표. RMSE/MAE, W=단기·중기1h/장기1d의 mean/CVaR(최악ceil20%), 전체 셀 과소예측 RMSE(w1), B=.6mean+.4CVaR, C=.5mean+.3CVaR+.2peak. 위험 손실 직접 학습 아님.
- 기준모델 대비 변화와 비교 가능 여부: 같은 profile·해상도·외생조건·scope에서만 비교. 4~7월 평균과 8월은 서로 다른 기간이다. 기존 native RF 8월 실험은 입력 형식이 달라 참고 링크로만 사용.
- 오차가 큰 조건·해석·한계: 미래 외생조건은 실측 대체·예보 오차0 가정. 보정값72개를 기존 종료시각 유일키로 검증. full/clean_targets/clean_targets_inputs 공통 마스크를 점수 전에 고정하며 입력 마스크는 F3와 계절 기준선 참조의 합집합. 보정 전 참값 확보 아님. 중첩 경로는 독립 표본 아님. 장기 원점 약28개로 월간 불확실성이 큼.
- 오류·경고·실패 또는 중단 원인: 없음; [].
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\performance\runs\20261003T201248_KST_0f606b_august_frozen\long_3d\xgboost\future_F3_selected; predictions/scope/horizon/peak/hourly/day/conditions, 모델·features·훈련원점/리드타임·config/status/log. 혼합/기준선은 새 fitted 모델 없음.
- 결론과 다음 실험: 8월 추가 확인을 기록하고 재튜닝하지 않는다. 실제 개선·악화와 보정값 제외 결과를 함께 보고한다.

| fold | scope | n_excluded_origins | n_unique_target_times | Loss_A | MAE | L_mean | L_CVaR | L_peak | Loss_B | Loss_C | tail_windows | n_origins | n_predictions | n_risk_windows |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| aug | full | 0 | 2880 | 40.2070 | 27.4342 | 30.0662 | 78.4569 | 11.9196 | 49.4225 | 40.9541 | 17 | 28 | 8064 | 84 |
| aug | clean_targets | 3 | 2592 | 42.4042 | 29.8460 | 32.5276 | 82.6745 | 12.2724 | 52.5864 | 43.5206 | 15 | 25 | 7200 | 75 |
| aug | clean_targets_inputs | 3 | 2592 | 42.4042 | 29.8460 | 32.5276 | 82.6745 | 12.2724 | 52.5864 | 43.5206 | 15 | 25 | 7200 | 75 |


기록 정정 이력(2026-10-03, Asia/Seoul): 리뷰에서 RSS 콜백이 이전 horizon 값을 보존하지 않음을 확인했다. 저장된 RSS 수치는 유지하고 표기를 마지막 fit 직후·예측 종료 관측값으로 정정했다. 예측·지표·모델은 변경하지 않았다.
