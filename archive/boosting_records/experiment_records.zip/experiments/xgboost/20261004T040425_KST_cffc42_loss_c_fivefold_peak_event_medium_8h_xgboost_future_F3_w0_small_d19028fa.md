# 실험 20261004T040425_KST_cffc42_loss_c_fivefold_peak_event_medium_8h_xgboost_future_F3_w0_small_d19028fa

- 상태: 완료
- 목적과 가설: 미래 전체 경로의 최대전력이 원점 기준 B를 초과할 확률을 직접 이진 분류한다. 확률 보정 여부는 같은 5-fold Brier로 비교한다.
- 시작·종료 시각 및 시간대: 2026-10-04T04:37:24.549291+09:00 / 2026-10-04T04:37:35.083771+09:00, Asia/Seoul.
- 모델·라이브러리 버전: xgboost classifier; {'numpy': '2.1.3', 'pandas': '2.2.3', 'scikit-learn': '1.6.1', 'xgboost': '3.4.1', 'lightgbm': '4.7.0', 'catboost': '1.2.10', 'joblib': '1.4.2', 'nbclient': '0.10.2'}; interpreter=C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\.venv_boosting\Scripts\python.exe.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv, SHA256=0173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7; 완료 fold=['apr', 'may', 'jun', 'jul', 'aug']; q90=170은 전체 기간에서 계산했다.
- 목표값·단위·예측 구간: max_h power_15min > B(origin)의 이진 사건, power kW, probability 0~1; medium_8h.
- 학습·검증·테스트 분할과 누수 점검: 4~8월 expanding 5-fold; 각 fold 이전 마지막28일은 확률 보정 전용. base 학습의 전체 H 끝<보정시작, 보정 전체H끝<검증월시작. 미래 power 중간입력 없음. 9월 선택 사용 없음.
- 전처리·특성·하이퍼파라미터·seed: F3, context=None, future, small, {'objective': 'binary:logistic', 'eval_metric': 'logloss', 'tree_method': 'hist', 'n_estimators': 120, 'max_depth': 3, 'learning_rate': 0.05, 'min_child_weight': 10, 'reg_lambda': 10, 'subsample': 0.9, 'colsample_bytree': 0.9, 'random_state': 42, 'n_jobs': 2}; seed42; origin 요약 입력과 알려진 B를 추가. 클래스 재가중·복제 없음.
- 이전 또는 기준 실험 링크와 변경 사항: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\experiments\xgboost\20261003T182425_KST_e84d50_performance_medium_8h_xgboost_future_F2_pooled.md; 구간 사건 경험 빈도 기준선, raw/monotone sigmoid 보정 비교. 점 모델과 분류 모델의 목적이 다르다.
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: .venv_boosting/Scripts/python.exe -B -X utf8 notebooks/_shared/peak_event_fivefold.py --stage cv; SHA256=12f2c999015944f11a0414d3af01d5fffc2da13ec842d522e1d46b6211b8626b.
- 실제 실행 시간·자원 사용량(측정한 경우): 10.500s; base fit=5, 보정 fit=5; CPU2threads; fold경계 RSS=517.7MiB, 실제 peak 미측정.
- 평가 지표·구간별 또는 fold별 결과: 아래 표. Brier 주지표, log loss 보조. 두 클래스가 없는 AUROC/AP는 미측정. 경보0.5는 진단이고 최적 운영 임계값이 아니다.
- 기준모델 대비 변화와 비교 가능 여부: 동일 origin/B/path 사건의 사전 학습 경험 빈도와 비교. 5월 평균과 9월은 별도다.
- 오차가 큰 조건·해석·한계: 장기 월별27~28경로, 경로 중첩. F1에도 사건 정의에 필요한 B(관측 전력 기반)를 입력하여 point F1과 정보 계약이 다르다. 미래 외생은 실측 대체 오차0 가정. 전체 q90와 이미 본9월로 인해 탐색 평가.
- 오류·경고·실패 또는 중단 원인: 없음; [].
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\performance\runs\20261004T040425_KST_cffc42_loss_c_fivefold\peak_event\medium_8h\xgboost\future_F3_w0_small_d19028fa; probabilities, fit/calibration origins, model/calibrator joblib, features, reliability CSV, config/state/metrics.
- 결론과 다음 실험: 완료5fold만 비교하고 raw/calibration/모델/F 선택을9월전에 동결한다. 단일 클래스 fit은 Jeffreys 상수확률로 기록한다.

| n_origins | n_positive | event_rate | Brier | LogLoss | AUROC | AP | mean_probability | recall_at_05 | precision_at_05 | true_positive | false_positive | false_negative | fold | method | n_fit | n_calibration | n_fit_positive | n_calibration_positive | base_single_class | n_features | fit_save_seconds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 712 | 16 | 0.0225 | 0.0218 | 0.1035 | 0.7160 | 0.1254 | 0.0289 | 0.0000 | nan | 0 | 0 | 16 | apr | raw | 1143 | 664 | 40 | 24 | False | 109 | 1.7319 |
| 712 | 16 | 0.0225 | 0.0218 | 0.1028 | 0.7160 | 0.1254 | 0.0355 | 0.0000 | nan | 0 | 0 | 16 | apr | calibrated | 1143 | 664 | 40 | 24 | False | 109 | 1.7406 |
| 712 | 16 | 0.0225 | 0.0221 | 0.1104 | 0.5000 | 0.0225 | 0.0355 | 0.0000 | nan | 0 | 0 | 16 | apr | baseline | 1143 | 664 | 40 | 24 | False | 109 | 1.7595 |
| 736 | 16 | 0.0217 | 0.0392 | 0.1180 | 0.9124 | 0.1125 | 0.0646 | 0.0000 | 0.0000 | 0 | 29 | 16 | may | raw | 1863 | 664 | 72 | 8 | False | 109 | 0.6292 |
| 736 | 16 | 0.0217 | 0.0214 | 0.1079 | 0.5000 | 0.0217 | 0.0120 | 0.0000 | nan | 0 | 0 | 16 | may | calibrated | 1863 | 664 | 72 | 8 | False | 109 | 0.6367 |
| 736 | 16 | 0.0217 | 0.0214 | 0.1066 | 0.5000 | 0.0217 | 0.0317 | 0.0000 | nan | 0 | 0 | 16 | may | baseline | 1863 | 664 | 72 | 8 | False | 109 | 0.6453 |
| 712 | 32 | 0.0449 | 0.0234 | 0.0784 | 0.9897 | 0.8552 | 0.0378 | 0.1562 | 1.0000 | 5 | 0 | 27 | jun | raw | 2607 | 664 | 88 | 8 | False | 109 | 0.7278 |
| 712 | 32 | 0.0449 | 0.0350 | 0.1091 | 0.9897 | 0.8552 | 0.0126 | 0.0000 | nan | 0 | 0 | 32 | jun | calibrated | 2607 | 664 | 88 | 8 | False | 109 | 0.7360 |
| 712 | 32 | 0.0449 | 0.0432 | 0.1870 | 0.5000 | 0.0449 | 0.0294 | 0.0000 | nan | 0 | 0 | 32 | jun | baseline | 2607 | 664 | 88 | 8 | False | 109 | 0.7431 |
| 736 | 22 | 0.0299 | 0.0257 | 0.1073 | 0.8547 | 0.2514 | 0.0181 | 0.0000 | nan | 0 | 0 | 22 | jul | raw | 3327 | 664 | 104 | 24 | False | 109 | 0.5991 |
| 736 | 22 | 0.0299 | 0.0275 | 0.1118 | 0.8547 | 0.2514 | 0.0362 | 0.2273 | 0.2273 | 5 | 17 | 17 | jul | calibrated | 3327 | 664 | 104 | 24 | False | 109 | 0.6063 |
| 736 | 22 | 0.0299 | 0.0290 | 0.1344 | 0.5000 | 0.0299 | 0.0321 | 0.0000 | nan | 0 | 0 | 22 | jul | baseline | 3327 | 664 | 104 | 24 | False | 109 | 0.6153 |
| 736 | 16 | 0.0217 | 0.0528 | 0.1761 | 0.7109 | 0.0442 | 0.0810 | 0.0000 | 0.0000 | 0 | 44 | 16 | aug | raw | 4071 | 664 | 141 | 9 | False | 109 | 1.2596 |
| 736 | 16 | 0.0217 | 0.0253 | 0.1171 | 0.7109 | 0.0442 | 0.0285 | 0.0000 | nan | 0 | 0 | 16 | aug | calibrated | 4071 | 664 | 141 | 9 | False | 109 | 1.2668 |
| 736 | 16 | 0.0217 | 0.0214 | 0.1066 | 0.5000 | 0.0217 | 0.0317 | 0.0000 | nan | 0 | 0 | 16 | aug | baseline | 4071 | 664 | 141 | 9 | False | 109 | 1.2729 |
