# 실험 20261003T220922_KST_5a836e_research_tuning_medium_8h_xgboost_observed_F1_w0_105c46614d

- 상태: 완료
- 목적과 가설: 선별 파라미터의 F/window7월 스크리닝; screening 월과전체CV를구분한다.
- 시작·종료 시각 및 시간대: 2026-10-03T22:35:01.466400+09:00 / 2026-10-03T22:35:02.708112+09:00, Asia/Seoul.
- 모델·라이브러리 버전: xgboost; Python3.13.5, {'numpy': '2.1.3', 'pandas': '2.2.3', 'scikit-learn': '1.6.1', 'xgboost': '3.4.1', 'lightgbm': '4.7.0', 'catboost': '1.2.10', 'joblib': '1.4.2', 'nbclient': '0.10.2'}.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv; SHA2560173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7; 실행fold=['jul'].
- 목표값·단위·예측 구간: power_15min kW, medium_8h, H=32개15분; refresh60분.
- 학습·검증·테스트 분할과 누수 점검: fold이전expanding·학습전체H끝<시작·검증전체H끝<종료. short7d/medium14d/long28d최대window공통지원. 9월은동결후만평가; 미래전력중간입력없음.
- 전처리·특성·하이퍼파라미터·seed: F1, context_days=None, observed; {'objective': 'reg:squarederror', 'eval_metric': 'rmse', 'tree_method': 'hist', 'booster': 'gbtree', 'n_estimators': 150, 'learning_rate': 0.05, 'max_depth': 4, 'min_child_weight': 5, 'reg_lambda': 5, 'reg_alpha': 0, 'gamma': 0, 'subsample': 0.9, 'colsample_bytree': 0.8, 'random_state': 42, 'n_jobs': 4}; seed42; pooled최대60000행원점균등리드타임,모든모델같은키.
- 이전 또는 기준 실험 링크와 변경 사항: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\experiments\xgboost\20261003T182425_KST_e84d50_performance_medium_8h_xgboost_observed_F3_pooled.md; [연구근거](C:/Users/User/Documents/KAMP/5. 자원 최적화 AI 데이터셋/docs/research/2026-10-03-load-forecasting-tuning-evidence.md); 기존결과보존·새공통지원의기준재학습。
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: .venv_boosting/Scripts/python.exe -B -X utf8 notebooks/_shared/run_research_tuning_notebook.py; C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\.venv_boosting\Scripts\python.exe; codeSHA256=bc1795d45a4d907d5c62a0a901e609730725e4a67f641e74c0f6740aaeed9514。
- 실제 실행 시간·자원 사용량(측정한 경우): 1.234s,새fit=1회,CPU4threads,fit/fold경계관측RSS 최댓값=485.6MiB, 실행중진짜peak미측정。
- 평가 지표·구간별 또는 fold별 결과: 아래표·RMSE월별 동일 가중。W=단기/중기1h·장기1d, CVaR최악ceil20%,L_peak전체셀과소예측RMSE,B=.6mean+.4CVaR,C=.5mean+.3CVaR+.2peak。
- 기준모델 대비 변화와 비교 가능 여부: 같은profile/원점/window지원/외생조건/평가fold에서 비교。2fold 스크리닝과 4fold CV를 혼동하지않음。
- 오차가 큰 조건·해석·한계: 조건/lead/peak/day표참조。관측전용vs미래실측대체예보오차0가정。9월14일만제공,중첩원점독립 아님。후보 수 제한·모든 조합 최적화아님。
- 오류·경고·실패 또는 중단 원인: 없음; []。
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\performance\runs\20261003T220922_KST_5a836e_research_tuning\medium_8h\xgboost\observed_F1_w0_105c46614d; fold별predictions/model/features/train_origins/training keys·metrics·로그。
- 결론과 다음 실험: 완료 fold만 비교하고 유망 후보만 4개월 CV 확인。9월 평가 후 새 선택·튜닝 없음。

| Loss_A | MAE | L_mean | L_CVaR | L_peak | Loss_B | Loss_C | tail_windows | n_origins | n_predictions | n_risk_windows | fold | n_train | n_train_scalar_rows | fit_predict_save_seconds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20.8175 | 14.6346 | 15.6401 | 37.4045 | 18.1313 | 24.3459 | 22.6677 | 1178 | 736 | 23552 | 5888 | jul | 3999 | 59985 | 1.1494 |
