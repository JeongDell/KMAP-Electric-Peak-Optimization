# 실험 20261004T040425_KST_cffc42_loss_c_fivefold_final_events_peak_event_short_1h_xgboost_observed_F2_w0_small_f8390790

- 상태: 완료
- 목적과 가설: 미래 전체 경로의 최대전력이 원점 기준 B를 초과할 확률을 직접 이진 분류한다. 확률 보정 여부는 같은 5-fold Brier로 비교한다.
- 시작·종료 시각 및 시간대: 2026-10-04T07:38:09.891192+09:00 / 2026-10-04T07:38:10.535259+09:00, Asia/Seoul.
- 모델·라이브러리 버전: xgboost classifier; {'numpy': '2.1.3', 'pandas': '2.2.3', 'scikit-learn': '1.6.1', 'xgboost': '3.4.1', 'lightgbm': '4.7.0', 'catboost': '1.2.10', 'joblib': '1.4.2', 'nbclient': '0.10.2'}; interpreter=C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\.venv_boosting\Scripts\python.exe.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv, SHA256=0173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7; 완료 fold=['sep']; q90=170은 전체 기간에서 계산했다.
- 목표값·단위·예측 구간: max_h power_15min > B(origin)의 이진 사건, power kW, probability 0~1; short_1h.
- 학습·검증·테스트 분할과 누수 점검: 동결 후 9월 재평가; 각 fold 이전 보정 창=28d. base 학습의 전체 H 끝<보정시작, 보정 전체H끝<검증월시작. 미래 power 중간입력 없음. 9월 선택 사용 없음.
- 전처리·특성·하이퍼파라미터·seed: F2, context=None, observed, small, {'objective': 'binary:logistic', 'eval_metric': 'logloss', 'tree_method': 'hist', 'n_estimators': 120, 'max_depth': 3, 'learning_rate': 0.05, 'min_child_weight': 10, 'reg_lambda': 10, 'subsample': 0.9, 'colsample_bytree': 0.9, 'random_state': 42, 'n_jobs': 2}; seed42; origin 요약 입력과 알려진 B를 추가. 클래스 재가중·복제 없음.
- 이전 또는 기준 실험 링크와 변경 사항: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\experiments\xgboost\20261003T182425_KST_e84d50_performance_short_1h_xgboost_observed_F2_regularized_2.md; 구간 사건 경험 빈도 기준선, raw/monotone sigmoid 보정 비교. 점 모델과 분류 모델의 목적이 다르다.
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: .venv_boosting/Scripts/python.exe -B -X utf8 notebooks/_shared/finalize_loss_c_fivefold.py; SHA256=0ab5153adb44d91e509e63a1d337fe0eaeabc9a62cb43077d462a85c92895626.
- 실제 실행 시간·자원 사용량(측정한 경우): 0.639s; base fit=1, 보정 fit=1; CPU2threads; fold경계 RSS=468.0MiB, 실제 peak 미측정.
- 평가 지표·구간별 또는 fold별 결과: 아래 표. Brier 주지표, log loss 보조. 두 클래스가 없는 AUROC/AP는 미측정. 경보0.5는 진단이고 최적 운영 임계값이 아니다.
- 기준모델 대비 변화와 비교 가능 여부: 동일 origin/B/path 사건의 사전 학습 경험 빈도와 비교. 개발 5-fold 평균과 9월은 별도다.
- 오차가 큰 조건·해석·한계: 장기 월별27~28경로, 경로 중첩. F1에도 사건 정의에 필요한 B(관측 전력 기반)를 입력하여 point F1과 정보 계약이 다르다. 미래 외생은 실측 대체 오차0 가정. 전체 q90와 이미 본9월로 인해 탐색 평가.
- 오류·경고·실패 또는 중단 원인: 없음; [].
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\performance\runs\20261004T040425_KST_cffc42_loss_c_fivefold\20261004T040425_KST_cffc42_loss_c_fivefold_final_events\peak_event\short_1h\xgboost\observed_F2_w0_small_f8390790; probabilities, fit/calibration origins, model/calibrator joblib, features, reliability CSV, config/state/metrics.
- 결론과 다음 실험: 완료5fold만 비교하고 raw/calibration/모델/F 선택을9월전에 동결한다. 단일 클래스 fit은 Jeffreys 상수확률로 기록한다.

| n_origins | n_positive | event_rate | Brier | LogLoss | AUROC | AP | mean_probability | recall_at_05 | precision_at_05 | true_positive | false_positive | false_negative | fold | method | n_fit | n_calibration | n_fit_positive | n_calibration_positive | base_single_class | n_features | fit_save_seconds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1341 | 10 | 0.0075 | 0.0058 | 0.0284 | 0.9204 | 0.4492 | 0.0042 | 0.0000 | None | 0 | 0 | 10 | sep | raw | 19963 | 2684 | 101 | 9 | False | 56 | 0.5247 |
| 1341 | 10 | 0.0075 | 0.0067 | 0.0315 | 0.9204 | 0.4492 | 0.0026 | 0.0000 | None | 0 | 0 | 10 | sep | calibrated | 19963 | 2684 | 101 | 9 | False | 56 | 0.5342 |
| 1341 | 10 | 0.0075 | 0.0074 | 0.0445 | 0.5000 | 0.0075 | 0.0049 | 0.0000 | None | 0 | 0 | 10 | sep | baseline | 19963 | 2684 | 101 | 9 | False | 56 | 0.5396 |


## 동결 후 9월 실제 분할과 민감도

- 선택된 출력은 raw; 선택 동결 SHA256=e788d27a4770724ec3d37fe20bc662b019e82ddd4b1a30db8daf8dd10c86186a. 알려진 9월 재평가이며 추가 튜닝 없음.
- fit 원점: 2021-01-08 00:15:00 ~ 2021-08-03 22:45:00, n=19963; 마지막 전체 H 종료=2021-08-03 23:45:00.
- calibration 원점: 2021-08-04 00:00:00 ~ 2021-08-31 22:45:00, n=2684; 마지막 전체 H 종료=2021-08-31 23:45:00.
- 보정용 라벨은 base 학습과 분리했다. 목표 보정, 최대 과거지원 전력 및 현재 월 B 산정 이력의 보정 여부를 포함한 공통 scope를 보고한다.

| profile | model | scenario_key | feature_set | context_days | spec_key | method | selected_method | scope | n_excluded_origins | n_origins | n_positive | event_rate | Brier | LogLoss | AUROC | AP | mean_probability | recall_at_05 | precision_at_05 | true_positive | false_positive | false_negative |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| short_1h | xgboost | observed | F2 | None | f8390790dc84bd7d9f9be4091f5ce79569ad71cabe2ad82f670638ceff03c24a | raw | raw | full | 0 | 1341 | 10 | 0.0075 | 0.0058 | 0.0284 | 0.9204 | 0.4492 | 0.0042 | 0.0000 | None | 0 | 0 | 10 |
| short_1h | xgboost | observed | F2 | None | f8390790dc84bd7d9f9be4091f5ce79569ad71cabe2ad82f670638ceff03c24a | calibrated | raw | full | 0 | 1341 | 10 | 0.0075 | 0.0067 | 0.0315 | 0.9204 | 0.4492 | 0.0026 | 0.0000 | None | 0 | 0 | 10 |
| short_1h | xgboost | observed | F2 | None | f8390790dc84bd7d9f9be4091f5ce79569ad71cabe2ad82f670638ceff03c24a | baseline | raw | full | 0 | 1341 | 10 | 0.0075 | 0.0074 | 0.0445 | 0.5000 | 0.0075 | 0.0049 | 0.0000 | None | 0 | 0 | 10 |
| short_1h | xgboost | observed | F2 | None | f8390790dc84bd7d9f9be4091f5ce79569ad71cabe2ad82f670638ceff03c24a | raw | raw | clean_targets | 5 | 1336 | 10 | 0.0075 | 0.0058 | 0.0285 | 0.9201 | 0.4492 | 0.0042 | 0.0000 | None | 0 | 0 | 10 |
| short_1h | xgboost | observed | F2 | None | f8390790dc84bd7d9f9be4091f5ce79569ad71cabe2ad82f670638ceff03c24a | calibrated | raw | clean_targets | 5 | 1336 | 10 | 0.0075 | 0.0067 | 0.0316 | 0.9201 | 0.4492 | 0.0026 | 0.0000 | None | 0 | 0 | 10 |
| short_1h | xgboost | observed | F2 | None | f8390790dc84bd7d9f9be4091f5ce79569ad71cabe2ad82f670638ceff03c24a | baseline | raw | clean_targets | 5 | 1336 | 10 | 0.0075 | 0.0074 | 0.0447 | 0.5000 | 0.0075 | 0.0049 | 0.0000 | None | 0 | 0 | 10 |
| short_1h | xgboost | observed | F2 | None | f8390790dc84bd7d9f9be4091f5ce79569ad71cabe2ad82f670638ceff03c24a | raw | raw | clean_targets_inputs | 1055 | 286 | 0 | 0.0000 | 0.0002 | 0.0036 | nan | nan | 0.0035 | nan | None | 0 | 0 | 0 |
| short_1h | xgboost | observed | F2 | None | f8390790dc84bd7d9f9be4091f5ce79569ad71cabe2ad82f670638ceff03c24a | calibrated | raw | clean_targets_inputs | 1055 | 286 | 0 | 0.0000 | 0.0000 | 0.0025 | nan | nan | 0.0024 | nan | None | 0 | 0 | 0 |
| short_1h | xgboost | observed | F2 | None | f8390790dc84bd7d9f9be4091f5ce79569ad71cabe2ad82f670638ceff03c24a | baseline | raw | clean_targets_inputs | 1055 | 286 | 0 | 0.0000 | 0.0000 | 0.0049 | nan | nan | 0.0049 | nan | None | 0 | 0 | 0 |
