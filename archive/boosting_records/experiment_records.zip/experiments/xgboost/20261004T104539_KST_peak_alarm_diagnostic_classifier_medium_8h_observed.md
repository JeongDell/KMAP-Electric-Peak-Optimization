# 실험 20261004T104539_KST_peak_alarm_diagnostic_classifier_medium_8h_observed

- 상태: 완료
- 목적과 가설: 이미 무가중인 피크 분류기의 raw/확률 보정/0.5 경보와 고정 임계값 진단. 전력 가중치 ablation과 분리.
- 시작·종료 시각 및 시간대: 2026-10-04T10:48:40.622129+09:00 / 2026-10-04T10:48:41.311120+09:00, Asia/Seoul.
- 모델·라이브러리 버전: xgboost; {'numpy': '2.1.3', 'pandas': '2.2.3', 'scikit-learn': '1.6.1', 'xgboost': '3.4.1', 'lightgbm': '4.7.0', 'catboost': '1.2.10', 'joblib': '1.4.2', 'nbclient': '0.10.2'}; 새 모델/보정 fit=0.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv; SHA256=0173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7;4~8월 및 알려진9월.
- 목표값·단위·예측 구간: medium_8h, 원점 발행B를 넘는 미래 max 사건, 확률0~1.
- 학습·검증·테스트 분할과 누수 점검: 기존 expanding5fold, base/calibration28d H purge, 기존 9월 저장 모델 재추론 확인. 9월로 임계값/모델 선택 없음.
- 전처리·특성·하이퍼파라미터·seed: F1, observed, context=None; {'objective': 'binary:logistic', 'eval_metric': 'logloss', 'tree_method': 'hist', 'n_estimators': 120, 'max_depth': 3, 'learning_rate': 0.05, 'min_child_weight': 10, 'reg_lambda': 10, 'subsample': 0.9, 'colsample_bytree': 0.9, 'random_state': 42, 'n_jobs': 2}; seed42. sample_weight/class_weight 없음.
- 이전 또는 기준 실험 링크와 변경 사항: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\experiments\xgboost\20261004T040425_KST_cffc42_loss_c_fivefold_peak_event_medium_8h_xgboost_observed_F1_w0_small_aeb7f0c4.md; 새 fit 없이 raw/cal과 임계값 민감도만 분해.
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: notebooks/evaluation/run_peak_alarm_diagnostic.py; SHA256=879a94250cc221e05e78069392884f2ab237d674ce85ea1ce912f053eaee8194.
- 실제 실행 시간·자원 사용량(측정한 경우): 새fit=0; 진단 개별 시간/RSS 미측정.
- 평가 지표·구간별 또는 fold별 결과: 아래표, threshold 민감도는 별도CSV; 선정출력=calibrated.
- 기준모델 대비 변화와 비교 가능 여부: raw/cal 동일사건/원점. 확률 모델과 P95 전력 조기경고는 출력 의미가 달라 Brier 직접 비교하지 않음.
- 오차가 큰 조건·해석·한계: 중첩 양성 원점, 실제 신규기록4셀/2일. 9월은 독립 테스트 아님. threshold grid는 운영 권고 선정이 아닌 고정 진단.
- 오류·경고·실패 또는 중단 원인: 없음; 저장 확률 재추론, sigmoid 일치, 사건라벨/원점/B 확인.
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\reports\20261004T104539_KST_peak_alarm_diagnostic; 모델원본=C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\performance\runs\20261004T040425_KST_cffc42_loss_c_fivefold\20261004T040425_KST_cffc42_loss_c_fivefold_final_events\peak_event\medium_8h\xgboost\observed_F1_w0_small_aeb7f0c4.
- 결론과 다음 실험: Brier만으로 경보 운영점을 정할 수 없음. 새 독립구간에서 미탐 비용과 오경보 한도를 정해 선택해야 함.

| profile | scenario_key | model | feature_set | fold | method | selected_method | max_probability | n_origins | n_positive | event_rate | Brier | LogLoss | AUROC | AP | mean_probability | recall_at_05 | precision_at_05 | true_positive | false_positive | false_negative | positive_MSE | negative_MSE | positive_contribution | negative_contribution | TP | FP | FN | TN | recall | precision | false_positive_rate | alarm_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| medium_8h | observed | xgboost | F1 | apr | raw | calibrated | 0.4106 | 712 | 16 | 0.0225 | 0.0262 | 0.1077 | 0.8257 | 0.0661 | 0.0499 | 0.0000 | nan | 0 | 0 | 16 | 0.8160 | 0.0080 | 0.0183 | 0.0078 | 0 | 0 | 16 | 696 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | observed | xgboost | F1 | apr | calibrated | calibrated | 0.2516 | 712 | 16 | 0.0225 | 0.0228 | 0.0989 | 0.8257 | 0.0661 | 0.0354 | 0.0000 | nan | 0 | 0 | 16 | 0.8724 | 0.0033 | 0.0196 | 0.0032 | 0 | 0 | 16 | 696 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | observed | xgboost | F1 | apr | baseline | calibrated | 0.0355 | 712 | 16 | 0.0225 | 0.0221 | 0.1104 | 0.5000 | 0.0225 | 0.0355 | 0.0000 | nan | 0 | 0 | 16 | 0.9302 | 0.0013 | 0.0209 | 0.0012 | 0 | 0 | 16 | 696 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | observed | xgboost | F1 | may | raw | calibrated | 0.6190 | 736 | 16 | 0.0217 | 0.0338 | 0.1258 | 0.8424 | 0.0860 | 0.0752 | 0.1250 | 0.1111 | 2 | 16 | 14 | 0.6450 | 0.0202 | 0.0140 | 0.0198 | 2 | 16 | 14 | 704 | 0.1250 | 0.1111 | 0.0222 | 0.0245 |
| medium_8h | observed | xgboost | F1 | may | calibrated | calibrated | 0.0486 | 736 | 16 | 0.0217 | 0.0209 | 0.0943 | 0.8424 | 0.0860 | 0.0145 | 0.0000 | nan | 0 | 0 | 16 | 0.9478 | 0.0003 | 0.0206 | 0.0003 | 0 | 0 | 16 | 720 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | observed | xgboost | F1 | may | baseline | calibrated | 0.0317 | 736 | 16 | 0.0217 | 0.0214 | 0.1066 | 0.5000 | 0.0217 | 0.0317 | 0.0000 | nan | 0 | 0 | 16 | 0.9375 | 0.0010 | 0.0204 | 0.0010 | 0 | 0 | 16 | 720 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | observed | xgboost | F1 | jun | raw | calibrated | 0.3752 | 712 | 32 | 0.0449 | 0.0287 | 0.1015 | 0.9586 | 0.6942 | 0.0454 | 0.0000 | nan | 0 | 0 | 32 | 0.5539 | 0.0040 | 0.0249 | 0.0038 | 0 | 0 | 32 | 680 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | observed | xgboost | F1 | jun | calibrated | calibrated | 0.2537 | 712 | 32 | 0.0449 | 0.0325 | 0.1061 | 0.9586 | 0.6942 | 0.0256 | 0.0000 | nan | 0 | 0 | 32 | 0.6949 | 0.0013 | 0.0312 | 0.0013 | 0 | 0 | 32 | 680 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | observed | xgboost | F1 | jun | baseline | calibrated | 0.0294 | 712 | 32 | 0.0449 | 0.0432 | 0.1870 | 0.5000 | 0.0449 | 0.0294 | 0.0000 | nan | 0 | 0 | 32 | 0.9420 | 0.0009 | 0.0423 | 0.0008 | 0 | 0 | 32 | 680 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | observed | xgboost | F1 | jul | raw | calibrated | 0.6088 | 736 | 22 | 0.0299 | 0.0203 | 0.0934 | 0.8537 | 0.5250 | 0.0293 | 0.3636 | 1.0000 | 8 | 0 | 14 | 0.6263 | 0.0016 | 0.0187 | 0.0016 | 8 | 0 | 14 | 714 | 0.3636 | 1.0000 | 0.0000 | 0.0109 |
| medium_8h | observed | xgboost | F1 | jul | calibrated | calibrated | 0.8982 | 736 | 22 | 0.0299 | 0.0200 | 0.0976 | 0.8537 | 0.5250 | 0.0444 | 0.3636 | 0.8889 | 8 | 1 | 14 | 0.5076 | 0.0050 | 0.0152 | 0.0048 | 8 | 1 | 14 | 713 | 0.3636 | 0.8889 | 0.0014 | 0.0122 |
| medium_8h | observed | xgboost | F1 | jul | baseline | calibrated | 0.0321 | 736 | 22 | 0.0299 | 0.0290 | 0.1344 | 0.5000 | 0.0299 | 0.0321 | 0.0000 | nan | 0 | 0 | 22 | 0.9368 | 0.0010 | 0.0280 | 0.0010 | 0 | 0 | 22 | 714 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | observed | xgboost | F1 | aug | raw | calibrated | 0.8550 | 736 | 16 | 0.0217 | 0.0507 | 0.1657 | 0.8760 | 0.1920 | 0.1055 | 0.5000 | 0.1569 | 8 | 43 | 8 | 0.4361 | 0.0421 | 0.0095 | 0.0412 | 8 | 43 | 8 | 677 | 0.5000 | 0.1569 | 0.0597 | 0.0693 |
| medium_8h | observed | xgboost | F1 | aug | calibrated | calibrated | 0.2859 | 736 | 16 | 0.0217 | 0.0197 | 0.0836 | 0.8760 | 0.1920 | 0.0276 | 0.0000 | nan | 0 | 0 | 16 | 0.7792 | 0.0028 | 0.0169 | 0.0028 | 0 | 0 | 16 | 720 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | observed | xgboost | F1 | aug | baseline | calibrated | 0.0317 | 736 | 16 | 0.0217 | 0.0214 | 0.1066 | 0.5000 | 0.0217 | 0.0317 | 0.0000 | nan | 0 | 0 | 16 | 0.9376 | 0.0010 | 0.0204 | 0.0010 | 0 | 0 | 16 | 720 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | observed | xgboost | F1 | sep | raw | calibrated | 0.5268 | 329 | 16 | 0.0486 | 0.0332 | 0.1354 | 0.8936 | 0.5830 | 0.0290 | 0.2500 | 1.0000 | 4 | 0 | 12 | 0.6505 | 0.0016 | 0.0316 | 0.0016 | 4 | 0 | 12 | 313 | 0.2500 | 1.0000 | 0.0000 | 0.0122 |
| medium_8h | observed | xgboost | F1 | sep | calibrated | calibrated | 0.3484 | 329 | 16 | 0.0486 | 0.0370 | 0.1451 | 0.8936 | 0.5830 | 0.0214 | 0.0000 | nan | 0 | 0 | 16 | 0.7465 | 0.0008 | 0.0363 | 0.0007 | 0 | 0 | 16 | 313 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | observed | xgboost | F1 | sep | baseline | calibrated | 0.0303 | 329 | 16 | 0.0486 | 0.0466 | 0.1993 | 0.5000 | 0.0486 | 0.0303 | 0.0000 | nan | 0 | 0 | 16 | 0.9402 | 0.0009 | 0.0457 | 0.0009 | 0 | 0 | 16 | 313 | 0.0000 | nan | 0.0000 | 0.0000 |
