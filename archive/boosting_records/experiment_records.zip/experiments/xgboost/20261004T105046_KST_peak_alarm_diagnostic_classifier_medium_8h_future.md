# 실험 20261004T105046_KST_peak_alarm_diagnostic_classifier_medium_8h_future

- 상태: 완료
- 목적과 가설: 이미 무가중인 피크 분류기의 raw/확률 보정/0.5 경보와 고정 임계값 진단. 전력 가중치 ablation과 분리.
- 시작·종료 시각 및 시간대: 2026-10-04T10:51:15.069112+09:00 / 2026-10-04T10:51:15.626528+09:00, Asia/Seoul.
- 모델·라이브러리 버전: xgboost; {'numpy': '2.1.3', 'pandas': '2.2.3', 'scikit-learn': '1.6.1', 'xgboost': '3.4.1', 'lightgbm': '4.7.0', 'catboost': '1.2.10', 'joblib': '1.4.2', 'nbclient': '0.10.2'}; 새 모델/보정 fit=0.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv; SHA256=0173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7;4~8월 및 알려진9월.
- 목표값·단위·예측 구간: medium_8h, 원점 발행B를 넘는 미래 max 사건, 확률0~1.
- 학습·검증·테스트 분할과 누수 점검: 기존 expanding5fold, base/calibration28d H purge, 기존 9월 저장 모델 재추론 확인. 9월로 임계값/모델 선택 없음.
- 전처리·특성·하이퍼파라미터·seed: F1, future, context=None; {'objective': 'binary:logistic', 'eval_metric': 'logloss', 'tree_method': 'hist', 'n_estimators': 120, 'max_depth': 3, 'learning_rate': 0.05, 'min_child_weight': 10, 'reg_lambda': 10, 'subsample': 0.9, 'colsample_bytree': 0.9, 'random_state': 42, 'n_jobs': 2}; seed42. sample_weight/class_weight 없음.
- 이전 또는 기준 실험 링크와 변경 사항: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\experiments\xgboost\20261004T040425_KST_cffc42_loss_c_fivefold_peak_event_medium_8h_xgboost_future_F1_w0_small_28475ad8.md; 새 fit 없이 raw/cal과 임계값 민감도만 분해.
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: notebooks/evaluation/run_peak_alarm_diagnostic.py; SHA256=6bd7b7e1952110b3cf9244733a81ba8a864878c5b16c749a172c652488196690.
- 실제 실행 시간·자원 사용량(측정한 경우): 새fit=0; 진단 개별 시간/RSS 미측정.
- 평가 지표·구간별 또는 fold별 결과: 아래표, threshold 민감도는 별도CSV; 선정출력=calibrated.
- 기준모델 대비 변화와 비교 가능 여부: raw/cal 동일사건/원점. 확률 모델과 P95 전력 조기경고는 출력 의미가 달라 Brier 직접 비교하지 않음.
- 오차가 큰 조건·해석·한계: 중첩 양성 원점, 실제 신규기록4셀/2일. 9월은 독립 테스트 아님. threshold grid는 운영 권고 선정이 아닌 고정 진단.
- 오류·경고·실패 또는 중단 원인: 없음; 저장 확률 재추론, sigmoid 일치, 사건라벨/원점/B 확인.
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\reports\20261004T105046_KST_peak_alarm_diagnostic; 모델원본=C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\performance\runs\20261004T040425_KST_cffc42_loss_c_fivefold\20261004T040425_KST_cffc42_loss_c_fivefold_final_events\peak_event\medium_8h\xgboost\future_F1_w0_small_28475ad8.
- 결론과 다음 실험: Brier만으로 경보 운영점을 정할 수 없음. 새 독립구간에서 미탐 비용과 오경보 한도를 정해 선택해야 함.

| profile | scenario_key | model | feature_set | fold | method | selected_method | max_probability | n_origins | n_positive | event_rate | Brier | LogLoss | AUROC | AP | mean_probability | recall_at_05 | precision_at_05 | true_positive | false_positive | false_negative | positive_MSE | negative_MSE | positive_contribution | negative_contribution | TP | FP | FN | TN | recall | precision | false_positive_rate | alarm_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| medium_8h | future | xgboost | F1 | apr | raw | calibrated | 0.4894 | 712 | 16 | 0.0225 | 0.0264 | 0.1121 | 0.7673 | 0.0482 | 0.0449 | 0.0000 | nan | 0 | 0 | 16 | 0.8863 | 0.0066 | 0.0199 | 0.0065 | 0 | 0 | 16 | 696 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | future | xgboost | F1 | apr | calibrated | calibrated | 0.2034 | 712 | 16 | 0.0225 | 0.0225 | 0.1046 | 0.7673 | 0.0482 | 0.0361 | 0.0000 | nan | 0 | 0 | 16 | 0.9063 | 0.0021 | 0.0204 | 0.0021 | 0 | 0 | 16 | 696 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | future | xgboost | F1 | apr | baseline | calibrated | 0.0355 | 712 | 16 | 0.0225 | 0.0221 | 0.1104 | 0.5000 | 0.0225 | 0.0355 | 0.0000 | nan | 0 | 0 | 16 | 0.9302 | 0.0013 | 0.0209 | 0.0012 | 0 | 0 | 16 | 696 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | future | xgboost | F1 | may | raw | calibrated | 0.6337 | 736 | 16 | 0.0217 | 0.0379 | 0.1393 | 0.7747 | 0.0490 | 0.0794 | 0.0000 | 0.0000 | 0 | 9 | 16 | 0.7398 | 0.0223 | 0.0161 | 0.0218 | 0 | 9 | 16 | 711 | 0.0000 | 0.0000 | 0.0125 | 0.0122 |
| medium_8h | future | xgboost | F1 | may | calibrated | calibrated | 0.0433 | 736 | 16 | 0.0217 | 0.0211 | 0.0986 | 0.7747 | 0.0490 | 0.0144 | 0.0000 | nan | 0 | 0 | 16 | 0.9582 | 0.0003 | 0.0208 | 0.0003 | 0 | 0 | 16 | 720 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | future | xgboost | F1 | may | baseline | calibrated | 0.0317 | 736 | 16 | 0.0217 | 0.0214 | 0.1066 | 0.5000 | 0.0217 | 0.0317 | 0.0000 | nan | 0 | 0 | 16 | 0.9375 | 0.0010 | 0.0204 | 0.0010 | 0 | 0 | 16 | 720 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | future | xgboost | F1 | jun | raw | calibrated | 0.5929 | 712 | 32 | 0.0449 | 0.0284 | 0.1056 | 0.9451 | 0.6904 | 0.0509 | 0.1875 | 1.0000 | 6 | 0 | 26 | 0.5322 | 0.0047 | 0.0239 | 0.0045 | 6 | 0 | 26 | 680 | 0.1875 | 1.0000 | 0.0000 | 0.0084 |
| medium_8h | future | xgboost | F1 | jun | calibrated | calibrated | 0.3735 | 712 | 32 | 0.0449 | 0.0334 | 0.1140 | 0.9451 | 0.6904 | 0.0231 | 0.0000 | nan | 0 | 0 | 32 | 0.7247 | 0.0009 | 0.0326 | 0.0009 | 0 | 0 | 32 | 680 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | future | xgboost | F1 | jun | baseline | calibrated | 0.0294 | 712 | 32 | 0.0449 | 0.0432 | 0.1870 | 0.5000 | 0.0449 | 0.0294 | 0.0000 | nan | 0 | 0 | 32 | 0.9420 | 0.0009 | 0.0423 | 0.0008 | 0 | 0 | 32 | 680 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | future | xgboost | F1 | jul | raw | calibrated | 0.5997 | 736 | 22 | 0.0299 | 0.0208 | 0.0963 | 0.8489 | 0.5202 | 0.0239 | 0.2273 | 1.0000 | 5 | 0 | 17 | 0.6604 | 0.0011 | 0.0197 | 0.0011 | 5 | 0 | 17 | 714 | 0.2273 | 1.0000 | 0.0000 | 0.0068 |
| medium_8h | future | xgboost | F1 | jul | calibrated | calibrated | 0.8256 | 736 | 22 | 0.0299 | 0.0199 | 0.0971 | 0.8489 | 0.5202 | 0.0399 | 0.3636 | 0.8889 | 8 | 1 | 14 | 0.5487 | 0.0036 | 0.0164 | 0.0035 | 8 | 1 | 14 | 713 | 0.3636 | 0.8889 | 0.0014 | 0.0122 |
| medium_8h | future | xgboost | F1 | jul | baseline | calibrated | 0.0321 | 736 | 22 | 0.0299 | 0.0290 | 0.1344 | 0.5000 | 0.0299 | 0.0321 | 0.0000 | nan | 0 | 0 | 22 | 0.9368 | 0.0010 | 0.0280 | 0.0010 | 0 | 0 | 22 | 714 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | future | xgboost | F1 | aug | raw | calibrated | 0.8028 | 736 | 16 | 0.0217 | 0.0391 | 0.1355 | 0.9121 | 0.4201 | 0.0974 | 0.5000 | 0.2105 | 8 | 30 | 8 | 0.3954 | 0.0311 | 0.0086 | 0.0305 | 8 | 30 | 8 | 690 | 0.5000 | 0.2105 | 0.0417 | 0.0516 |
| medium_8h | future | xgboost | F1 | aug | calibrated | calibrated | 0.1850 | 736 | 16 | 0.0217 | 0.0191 | 0.0771 | 0.9121 | 0.4201 | 0.0194 | 0.0000 | nan | 0 | 0 | 16 | 0.8331 | 0.0010 | 0.0181 | 0.0010 | 0 | 0 | 16 | 720 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | future | xgboost | F1 | aug | baseline | calibrated | 0.0317 | 736 | 16 | 0.0217 | 0.0214 | 0.1066 | 0.5000 | 0.0217 | 0.0317 | 0.0000 | nan | 0 | 0 | 16 | 0.9376 | 0.0010 | 0.0204 | 0.0010 | 0 | 0 | 16 | 720 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | future | xgboost | F1 | sep | raw | calibrated | 0.3728 | 329 | 16 | 0.0486 | 0.0355 | 0.1491 | 0.8561 | 0.5660 | 0.0254 | 0.0000 | nan | 0 | 0 | 16 | 0.6969 | 0.0016 | 0.0339 | 0.0016 | 0 | 0 | 16 | 313 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | future | xgboost | F1 | sep | calibrated | calibrated | 0.2849 | 329 | 16 | 0.0486 | 0.0377 | 0.1556 | 0.8561 | 0.5660 | 0.0202 | 0.0000 | nan | 0 | 0 | 16 | 0.7566 | 0.0010 | 0.0368 | 0.0009 | 0 | 0 | 16 | 313 | 0.0000 | nan | 0.0000 | 0.0000 |
| medium_8h | future | xgboost | F1 | sep | baseline | calibrated | 0.0303 | 329 | 16 | 0.0486 | 0.0466 | 0.1993 | 0.5000 | 0.0486 | 0.0303 | 0.0000 | nan | 0 | 0 | 16 | 0.9402 | 0.0009 | 0.0457 | 0.0009 | 0 | 0 | 16 | 313 | 0.0000 | nan | 0.0000 | 0.0000 |
