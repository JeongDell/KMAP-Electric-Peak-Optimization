# 실험 20261004T040425_KST_cffc42_loss_c_fivefold_final_points_weighted_long_3d_xgboost_observed_F3_w7_c53098a08e

- 상태: 완료
- 목적과 가설: 동일 파라미터/F/입력 창의 무가중 후보와 비교하여 cap2 연속·확률 연계 가중 제곱오차 학습의 절충을 확인한다. 평가 cap은모두2다.
- 시작·종료 시각 및 시간대: 2026-10-04T07:37:00.010024+09:00 / 2026-10-04T07:37:01.583222+09:00, Asia/Seoul.
- 모델·라이브러리 버전: xgboost, Python=3.13.5, {'numpy': '2.1.3', 'pandas': '2.2.3', 'scikit-learn': '1.6.1', 'xgboost': '3.4.1', 'lightgbm': '4.7.0', 'catboost': '1.2.10', 'joblib': '1.4.2', 'nbclient': '0.10.2'}.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv, SHA256=0173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7; 완료 fold=['sep'].
- 목표값·단위·예측 구간: power_15min kW, long_3d, H=28815분 셀.
- 학습·검증·테스트 분할과 누수 점검: 4~8월 expanding, train 전체H끝<월시작, valid 전체H끝<월끝. sample weights의 p_ref는 그 학습 원점 당시 이전 월 데이터만 학습한 무가중 RF OOF. 현 검증월·9월 예측을 학습 가중치에 쓰지 않는다. Jan/OOF 월경계 gaps는 w1.
- 전처리·특성·하이퍼파라미터·seed: F3, observed, context=7, {'objective': 'reg:squarederror', 'eval_metric': 'rmse', 'tree_method': 'hist', 'booster': 'gbtree', 'n_estimators': 150, 'learning_rate': 0.05, 'max_depth': 4, 'min_child_weight': 5, 'reg_lambda': 5, 'reg_alpha': 0, 'gamma': 0, 'subsample': 0.9, 'colsample_bytree': 0.8, 'random_state': 42, 'n_jobs': 4}; seed42. 학습 cell w=1+(2-1)*g(y,B)*(1+p_ref)/2. RF native4는 원점 평균 w, scalar direct/pooled는 해당 lead w. 미래 target은 학습 가중치 계산용 정답이며 예측 입력이 아니다.
- 이전 또는 기준 실험 링크와 변경 사항: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\experiments\xgboost\20261004T040425_KST_cffc42_loss_c_fivefold_long_3d_xgboost_observed_F3_w7_e07b5d2bca.md; 해당 기준 후보에서 sample_weight만 바꾸고 파라미터를 다시 탐색하지 않는다. 미래 외생 오차0 기준 교사 확률을 쓰는 탐색 조건을 보존한다.
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: .venv_boosting/Scripts/python.exe -B -X utf8 notebooks/_shared/weighted_tree_fivefold.py; codeSHA256=acf57fb38b8d94aaf9b8b1943e83364cec8746459f6053f44b271e894448c83d.
- 실제 실행 시간·자원 사용량(측정한 경우): 1.565s; 새fit=1; CPU4threads; fold경계RSS=486.2MiB, 실제peak 미측정.
- 평가 지표·구간별 또는 fold별 결과: 아래표는 기본 w1 지표. 확정 공통 p_ref/cap2 C는 probability_linked_fold_metrics.csv와 아래 평가 이력에 별도 저장한다. 대표 선택은 같은 공통 C의5개월 동일가중 평균이다.
- 기준모델 대비 변화와 비교 가능 여부: 동일 분할/원점/입력/파라미터, sample weight만 변경. 이 학습은 weighted squared error이며 과소오차/CVaR/복합 C를 직접 최적화하지 않는다.
- 오차가 큰 조건·해석·한계: 가중치를 적용하면 과소/과대 절충이 생길 수 있어 RMSE와 고부하 양방향 오차를 같이 보고한다. 이전 무가중 선정 후보만 재가중하므로 가중 모델의 전역 최적 파라미터 탐색이 아니다. global q90와 이전9월 노출로 탐색 평가.
- 오류·경고·실패 또는 중단 원인: 없음; [].
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\performance\runs\20261004T040425_KST_cffc42_loss_c_fivefold\20261004T040425_KST_cffc42_loss_c_fivefold_final_points\weighted_points\long_3d\xgboost\observed_F3_w7_c53098a08e; 모델/예측/특성/학습원점/가중치/OOF출처/지표/상태.
- 결론과 다음 실험: 완료5-fold 후보만 무가중 풀에 추가해 비교하고, 최종 선택을 동결한 후9월을 재평가한다.

| Loss_A | MAE | L_mean | L_CVaR | L_peak | Loss_B | Loss_C | tail_windows | n_origins | n_predictions | n_risk_windows | fold | n_train | n_train_scalar_rows | n_oof_supported |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 10.3071 | 7.4085 | 9.5483 | 14.6277 | 5.6694 | 11.5800 | 10.2963 | 8 | 12 | 3456 | 36 | sep | 211 | 59924 | 191 |


## 동결 후 9월 재평가

- 최종 학습 기간은 1~8월, 전체 H 종료<9/1. 입력·F·파라미터·C·확률 보정 선택은 4~8월5-fold 완료 후 동결했다.
- source에는9/15 00:00 종료 셀까지 존재한다. 제공된 완전 경로를 모두 평가하며, 참조 RF의 엄격9/15 cutoff보다 마지막 경로 하나가 추가된다. 공통 평가 확률을 같은 저장 RF로 재추론해 키를 정렬했다.
- 공통 확률 연계 w2 C. 전체/보정 목표 제외/보정 목표·최대지원 전력이력·현재월B 산정이력 제외를 별도 보고한다. legacy 비교 키가 없는 경계 셀은 unknown으로 표시하고 clean scope에서 제외한다. 표본0은 미측정이다.
- frozen SHA256=e788d27a4770724ec3d37fe20bc662b019e82ddd4b1a30db8daf8dd10c86186a; 추가 튜닝 없음.

| profile | model | scenario_key | feature_set | context_days | spec_key | training_weight | scope | n_excluded_origins | Loss_A | MAE | L_mean | L_CVaR | L_peak | Loss_B | Loss_C | tail_windows | n_predictions | n_risk_windows | n_origins | n_high_cells | high_under_RMSE | high_over_RMSE | path_max_under_RMSE | path_max_MAE | path_peak_time_MAE_minutes | path_peak_time_bias_minutes | n_peak_timing_paths | n_paths_max_tie_actual | n_paths_max_tie_predicted | peak_timing_tie_policy | n_peak_event_paths | event_peak_time_MAE_minutes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| long_3d | xgboost | observed | F3 | 7 | c53098a08e4103179a8792ed54ab596e7cc5ee433c463cd3685dfc5f3903ac10 | reference_linked_cap2 | full | 0 | 10.3071 | 7.4085 | 9.5483 | 14.6277 | 6.1124 | 11.5800 | 10.3849 | 8.0000 | 3456.0000 | 36.0000 | 12 | 723.0000 | 7.8160 | 6.7857 | 17.4065 | 16.5280 | 1008.7500 | 323.7500 | 12.0000 | 2.0000 | 5.0000 | earliest | 4.0000 | 1061.2500 |
| long_3d | xgboost | observed | F3 | 7 | c53098a08e4103179a8792ed54ab596e7cc5ee433c463cd3685dfc5f3903ac10 | reference_linked_cap2 | clean_targets | 3 | 9.1253 | 6.7558 | 8.4617 | 12.5397 | 6.2946 | 10.0929 | 9.2517 | 6.0000 | 2592.0000 | 27.0000 | 9 | 462.0000 | 8.8105 | 6.0054 | 17.9288 | 17.2761 | 681.6667 | 91.6667 | 9.0000 | 2.0000 | 4.0000 | earliest | 3.0000 | 930.0000 |
| long_3d | xgboost | observed | F3 | 7 | c53098a08e4103179a8792ed54ab596e7cc5ee433c463cd3685dfc5f3903ac10 | reference_linked_cap2 | clean_targets_inputs | 12 | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | 0 | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan |
