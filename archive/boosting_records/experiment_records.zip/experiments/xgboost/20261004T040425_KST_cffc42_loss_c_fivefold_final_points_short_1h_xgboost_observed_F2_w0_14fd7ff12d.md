# 실험 20261004T040425_KST_cffc42_loss_c_fivefold_final_points_short_1h_xgboost_observed_F2_w0_14fd7ff12d

- 상태: 완료
- 목적과 가설: 동결 5-fold 선택의 1~8월 재학습 및 알려진 9월 재평가; 이미 공개된 9월의 재평가, 새 선택 없음.
- 시작·종료 시각 및 시간대: 2026-10-04T07:33:41.795926+09:00 / 2026-10-04T07:33:47.383333+09:00, Asia/Seoul.
- 모델·라이브러리 버전: xgboost; Python3.13.5, {'numpy': '2.1.3', 'pandas': '2.2.3', 'scikit-learn': '1.6.1', 'xgboost': '3.4.1', 'lightgbm': '4.7.0', 'catboost': '1.2.10', 'joblib': '1.4.2', 'nbclient': '0.10.2'}.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv; SHA2560173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7; 실행fold=['sep'].
- 목표값·단위·예측 구간: power_15min kW, short_1h, H=4개15분; refresh15분.
- 학습·검증·테스트 분할과 누수 점검: fold이전expanding·학습전체H끝<시작·검증전체H끝<종료. short7d/medium14d/long28d최대window공통지원. 9월은동결후만평가; 미래전력중간입력없음.
- 전처리·특성·하이퍼파라미터·seed: F2, context_days=None, observed; {'objective': 'reg:squarederror', 'eval_metric': 'rmse', 'tree_method': 'hist', 'booster': 'gbtree', 'n_estimators': 500, 'learning_rate': 0.05, 'max_depth': 4, 'min_child_weight': 5, 'reg_lambda': 5, 'reg_alpha': 0, 'gamma': 0, 'subsample': 0.9, 'colsample_bytree': 0.8, 'random_state': 42, 'n_jobs': 4}; seed42; pooled최대60000행원점균등리드타임,모든모델같은키.
- 이전 또는 기준 실험 링크와 변경 사항: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\experiments\xgboost\20261003T182425_KST_e84d50_performance_short_1h_xgboost_observed_F2_regularized_2.md; [연구근거](C:/Users/User/Documents/KAMP/5. 자원 최적화 AI 데이터셋/docs/research/2026-10-03-load-forecasting-tuning-evidence.md); 기존결과보존·새공통지원의기준재학습。
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: .venv_boosting/Scripts/python.exe -B -X utf8 notebooks/_shared/run_research_tuning_notebook.py; C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\.venv_boosting\Scripts\python.exe; codeSHA256=bc1795d45a4d907d5c62a0a901e609730725e4a67f641e74c0f6740aaeed9514。
- 실제 실행 시간·자원 사용량(측정한 경우): 5.580s,새fit=4회,CPU4threads,fit/fold경계관측RSS 최댓값=291.3MiB, 실행중진짜peak미측정。
- 평가 지표·구간별 또는 fold별 결과: 아래표·RMSE월별 동일 가중。W=단기/중기1h·장기1d, CVaR최악ceil20%,L_peak전체셀과소예측RMSE,B=.6mean+.4CVaR,C=.5mean+.3CVaR+.2peak。
- 기준모델 대비 변화와 비교 가능 여부: 같은profile/원점/window지원/외생조건/평가fold에서 비교。2fold 스크리닝과 4fold CV를 혼동하지않음。
- 오차가 큰 조건·해석·한계: 조건/lead/peak/day표참조。관측전용vs미래실측대체예보오차0가정。9월14일만제공,중첩원점독립 아님。후보 수 제한·모든 조합 최적화아님。
- 오류·경고·실패 또는 중단 원인: 없음; []。
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\performance\runs\20261004T040425_KST_cffc42_loss_c_fivefold\20261004T040425_KST_cffc42_loss_c_fivefold_final_points\short_1h\xgboost\observed_F2_w0_14fd7ff12d; fold별predictions/model/features/train_origins/training keys·metrics·로그。
- 결론과 다음 실험: 완료 fold만 비교하고 유망 후보만 9월 고정 CV 확인。9월 평가 후 새 선택·튜닝 없음。

| Loss_A | MAE | L_mean | L_CVaR | L_peak | Loss_B | Loss_C | tail_windows | n_origins | n_predictions | n_risk_windows | fold | n_train | n_train_scalar_rows | fit_predict_save_seconds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 8.9583 | 6.0652 | 7.0254 | 14.8190 | 6.5079 | 10.1428 | 9.2600 | 269 | 1341 | 5364 | 1341 | sep | 22651 | 22651 | 5.5351 |


## 동결 후 9월 재평가

- 최종 학습 기간은 1~8월, 전체 H 종료<9/1. 입력·F·파라미터·C·확률 보정 선택은 4~8월5-fold 완료 후 동결했다.
- source에는9/15 00:00 종료 셀까지 존재한다. 제공된 완전 경로를 모두 평가하며, 참조 RF의 엄격9/15 cutoff보다 마지막 경로 하나가 추가된다. 공통 평가 확률을 같은 저장 RF로 재추론해 키를 정렬했다.
- 공통 확률 연계 w2 C. 전체/보정 목표 제외/보정 목표·최대지원 전력이력·현재월B 산정이력 제외를 별도 보고한다. legacy 비교 키가 없는 경계 셀은 unknown으로 표시하고 clean scope에서 제외한다. 표본0은 미측정이다.
- frozen SHA256=e788d27a4770724ec3d37fe20bc662b019e82ddd4b1a30db8daf8dd10c86186a; 추가 튜닝 없음.

| profile | model | scenario_key | feature_set | context_days | spec_key | training_weight | scope | n_excluded_origins | Loss_A | MAE | L_mean | L_CVaR | L_peak | Loss_B | Loss_C | tail_windows | n_predictions | n_risk_windows | n_origins | n_high_cells | high_under_RMSE | high_over_RMSE | path_max_under_RMSE | path_max_MAE | path_peak_time_MAE_minutes | path_peak_time_bias_minutes | n_peak_timing_paths | n_paths_max_tie_actual | n_paths_max_tie_predicted | peak_timing_tie_policy | n_peak_event_paths | event_peak_time_MAE_minutes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| short_1h | xgboost | observed | F2 | None | 14fd7ff12d626e8f3b2454602510eb83ff0e0b16566fd2610271e7075efe4743 | None | full | 0 | 8.9583 | 6.0652 | 7.0254 | 14.8190 | 6.9478 | 10.1428 | 9.3479 | 269 | 5364 | 1341 | 1341 | 1148 | 10.0842 | 5.4223 | 8.0849 | 6.3078 | 14.0604 | 0.7718 | 1341 | 249 | 0 | earliest | 10 | 10.5000 |
| short_1h | xgboost | observed | F2 | None | 14fd7ff12d626e8f3b2454602510eb83ff0e0b16566fd2610271e7075efe4743 | None | clean_targets | 5 | 8.6764 | 5.9935 | 6.9241 | 14.3936 | 6.9585 | 9.9119 | 9.1718 | 268 | 5344 | 1336 | 1336 | 1145 | 10.0939 | 5.4294 | 8.0988 | 6.2688 | 14.0681 | 0.7298 | 1336 | 249 | 0 | earliest | 10 | 10.5000 |
| short_1h | xgboost | observed | F2 | None | 14fd7ff12d626e8f3b2454602510eb83ff0e0b16566fd2610271e7075efe4743 | None | clean_targets_inputs | 1055 | 8.0793 | 5.7834 | 6.7148 | 13.6675 | 5.7229 | 9.4959 | 8.6022 | 58 | 1144 | 286 | 286 | 245 | 6.8704 | 7.0718 | 6.7210 | 6.0087 | 15.0000 | 4.0909 | 286 | 45 | 0 | earliest | 0 | nan |
