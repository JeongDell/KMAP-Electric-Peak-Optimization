# 실험 20261003T182425_KST_e84d50_performance_medium_12h_lightgbm_observed_F3_pooled

- 상태: 완료
- 목적과 가설: 중·장기 공유리드타임 모델과F1/F2/F3 초기비교
- 시작·종료 시각 및 시간대: 2026-10-03T18:54:47.720573+09:00 / 2026-10-03T18:55:00.123232+09:00, Asia/Seoul.
- 모델·라이브러리 버전: lightgbm, {'numpy': '2.1.3', 'pandas': '2.2.3', 'scikit-learn': '1.6.1', 'xgboost': '3.4.1', 'lightgbm': '4.7.0', 'catboost': '1.2.10', 'joblib': '1.4.2', 'nbclient': '0.10.2'}.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv, SHA256 0173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7, 완료시각<2021-08-01, 원본미변경.
- 목표값·단위·예측 구간: power_15min kW, medium_12h의15분원경로. H=48steps,갱신=60min,위험W=60min. 보조출력은시간평균이며kWh아님.
- 학습·검증·테스트 분할과 누수 점검: 4~7월expanding,전체H정답끝<월경계strictpurge,모든F·모델·외생조건공통지원원점.8/9월미사용.전주/14dtarget패턴은origin이전,3d전일패턴은마지막관측일cycle반복.
- 전처리·특성·하이퍼파라미터·seed: F=F3, 외생=observed; {'objective': 'regression', 'metric': 'rmse', 'boosting_type': 'gbdt', 'n_estimators': 150, 'learning_rate': 0.05, 'num_leaves': 31, 'min_child_samples': 40, 'max_depth': -1, 'reg_lambda': 5, 'reg_alpha': 0, 'subsample': 1.0, 'subsample_freq': 0, 'colsample_bytree': 0.9, 'random_state': 42, 'n_jobs': 4, 'deterministic': True, 'force_col_wise': True, 'verbosity': -1}; seed42,원단위.입력형식=pooled_horizon; pooled훈련리드타임행최대60000,원점별동일개수균등무복원(seed42),평가전체경로; 단기는기존전체입력/4독립horizon(RF native4출력).
- 이전 또는 기준 실험 링크와 변경 사항: 기존부스팅F123/RF그리드; [이번계획](../../docs/superpowers/plans/2026-10-03-performance-and-horizons-plan.md); [인덱스](../README.md).
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: .venv_boosting/Scripts/python.exe notebooks/_shared/run_performance_notebooks.py; interpreter=C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\.venv_boosting\Scripts\python.exe; code SHA256={'performance_train.py': '878c25bf7c3f2f125c4a54eaa20125fc4d6fc26be5899185559c2c70e61d5f6e', 'performance_profiles.py': 'e4d6c0eae7a2bf643ce30b40158d5b27f04d28da331ba2220edbeca8119c9b43', 'boosting_common.py': 'a9c8dd42417219e67dd6b7a8327b74ba4a8172d368ce19a8292d7025421d19e4', 'rf_current_data.py': '70b983520a4cfcee6551953f29e9466c083608244fdf05503cd4ca93b62f7fa4'}; Git없는workspace.
- 실제 실행 시간·자원 사용량(측정한 경우): 12.298s,새fit=4; CPU4threads,fold경계관측RSS최대=304.0MiB,진짜peak미측정.
- 평가 지표·구간별 또는 fold별 결과: 아래표,단위kW.월별동일가중RMSE선정.위험window별L_mean/오차worstceil20%CVaR,L_peak전체셀과소예측RMSE(w1),B=.6mean+.4CVaR,C=.5mean+.3CVaR+.2peak.직접위험손실학습아님。
- 기준모델 대비 변화와 비교 가능 여부: 같은profile·지원원점·출력해상도·외생조건내비교.단기와중장기점수를합친순위금지.중장기pooled는단기독립horizon과구조다름。
- 오차가 큰 조건·해석·한계: 조건/날짜/horizon/경로max표참조;중첩경로독립아님.장기검증월별27/28안팎원점의한계.미래조건=실측대체예보오차0가정,실제운영예보검증아님.초기중장기설정은최적값아님。
- 오류·경고·실패 또는 중단 원인: 없음,Python경고=[]。
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\performance\runs\20261003T182425_KST_e84d50_performance\medium_12h\lightgbm\observed_F3_pooled; config/status/fold/horizon/peak/aggregation/predictions/train_origins/모델/로그。
- 결론과 다음 실험: 기존후보보다개선없으면기존유지;이번제한탐색이후추가무제한확대없음.실제수치로구간별후보추천。

| fold | n_train | n_train_scalar_rows | fit_predict_save_seconds | Loss_A | MAE | L_mean | L_CVaR | L_peak | Loss_B | Loss_C | tail_windows | n_origins | n_predictions | n_risk_windows |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| apr | 1979 | 59370 | 1.6435 | 39.9708 | 24.3237 | 25.3450 | 77.9695 | 30.2917 | 46.3948 | 42.1217 | 1700 | 708 | 33984 | 8496 |
| may | 2699 | 59378 | 1.6643 | 30.7390 | 16.6540 | 17.6622 | 56.6841 | 20.3714 | 33.2710 | 29.9106 | 1757 | 732 | 35136 | 8784 |
| jun | 3443 | 58531 | 1.7559 | 18.6309 | 12.5943 | 13.4781 | 32.4639 | 10.5817 | 21.0724 | 18.5945 | 1700 | 708 | 33984 | 8496 |
| jul | 4163 | 58282 | 2.2003 | 20.0252 | 13.1579 | 14.1923 | 36.7553 | 13.9725 | 23.2175 | 20.9172 | 1757 | 732 | 35136 | 8784 |
