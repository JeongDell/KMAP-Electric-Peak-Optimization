# 실험 20261003T222813_KST_f6c867_neural_f123_short_1h_F3_lossA_august_confirmation

- 상태: 완료
- 목적과 가설: dlinear/short_1h/F3/학습LossA의기본성능과누적피처·손실효과. phase=august_confirmation.
- 시작·종료 시각 및 시간대: 2026-10-03T22:29:06.557930+09:00 / 2026-10-03T22:29:10.695400+09:00, Asia/Seoul.
- 모델·라이브러리 버전: dlinear; Python3.12.10; {'torch': '2.12.1', 'numpy': '2.4.6', 'pandas': '3.0.3', 'scikit-learn': '1.9.0'}. DLinear/GRU에공유선형context추가,PatchTST는LayerNorm1층경량변형.
- 데이터 위치·버전 또는 해시·사용 범위: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\preprocessed_20261002\timeseries_15min_v1_previous_week.csv; SHA256 0173fc8f809c5f679a722ff45a41f01df06c643ef9d1d66c34f7a0b75b92b4d7; 종료시각<2021-09-01. 보정대조C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\data\processed\timeseries_all.csv; SHA256757979cf6e85d962b2fd3900bf45b4c8c1036d22a1cb9063e6f573af28fb1ce4. 원본보존.
- 목표값·단위·예측 구간: power_15min kW, H=4개의15분원경로,발행주기15분. 평균전력도kW.
- 학습·검증·테스트 분할과 누수 점검: 4~7월expanding 또는동결후8월추가확인; 전체H정답끝<월경계; 원점마다관측이력갱신,월내모델고정;9월미사용. 미래전력·미래외생실측입력없음.
- 전처리·특성·하이퍼파라미터·seed: 공통관측전력96개+RF식F3context;학습전용scale,범주그대로;seed42,CPU4threads,Adam lr.001/weight_decay.0001,batch256,clip1.0,最大epoch6(단중기)/30(장기),fit당15초배치경계상한.신경망F1은RF F1보다전력이력정보가많다.
- 이전 또는 기준 실험 링크와 변경 사항: [설계](../../docs/superpowers/specs/2026-10-03-neural-f123-design.md);[설계검토](../../notebooks/evaluation/NEURAL_DESIGN_REVIEW_20261003.md);[손실문서](../../docs/loss%20function.md). 기존실험은덮어쓰지않음.
- 실행 명령·환경·코드 버전 또는 코드 식별 정보: C:\Users\User\AppData\Local\Programs\Python\Python312\python.exe -B -X utf8 notebooks/_shared/run_neural_notebooks.py;Git없는workspace;code SHA256={'neural_experiments.py': '3aa0fc8ae81fce173229f95181318ed6d699f299b9d1e0a7b031c9f2ab5d9b3b', 'neural_data.py': '67bb17d3b368397f2e727bd028ef81e74a497457136deffc47c02338e3001d35', 'neural_train.py': '092a6448b43088ba5178419a3f707871adf4be78dcc00c5afc7088bff595f558', 'neural_models.py': '75afde61da0d067c549dbd99391ad1961fd1108219fcbe01d8545dcf037459ce', 'performance_profiles.py': 'e4d6c0eae7a2bf643ce30b40158d5b27f04d28da331ba2220edbeca8119c9b43', 'rf_current_data.py': '70b983520a4cfcee6551953f29e9466c083608244fdf05503cd4ca93b62f7fa4', 'forecast_common.py': '4093c76a243c18181a958d67e6137c3e891a26236ba71d9d48e29331fc91ce15'}.
- 실제 실행 시간·자원 사용량(측정한 경우): 학습누적3.632128초,학습·추론·저장wall4.131초,fold별완료epoch·종료사유는표/curve/config;모델전체예산1800초(내부시작1700초);실제최대메모리는미측정.
- 평가 지표·구간별 또는 fold별 결과: 아래표단위kW. A전체RMSE,B=.6mean+.4CVaR,C=.5mean+.3CVaR+.2peak,W=60분·원점내블록,w1·전체셀평균후root,tail=ceil20%。학습B/C는minibatch근사,평가는전체fold정확재계산.主지표4개월동일가중RMSE,MAE보조.
- 기준모델 대비 변화와 비교 가능 여부: 같은profile·공통원점·민감도범위의직전값/전날반복/전주반복대비. RF F1과정보량차이·라이브러리환경차이가있어순수구조차이해석금지.
- 오차가 큰 조건·해석·한계: 평가fold 중RMSE가가장큰구간=aug,RMSE=14.0024kW,N=2972원점. 그fold의최대조건오차=weekday:0,RMSE=19.0920kW,셀1920개/원점495개. 조건은사후진단이고인과효과가아니다. 중첩·소표본·epoch차이·생산량보정가정의제한이남는다.
- 오류·경고·실패 또는 중단 원인: 없음. fit_time_limit은완전epoch만복원;완전epoch0이면점수금지.
- 예측·모델·표·그래프·로그의 저장 경로: C:\Users\User\Documents\KAMP\5. 자원 최적화 AI 데이터셋\artifacts\dlinear\runs\20261003T222813_KST_f6c867_neural_f123\short_1h\F3_lossA_august_confirmation;fold별model.pt/scaler.json/train_origins.csv/predictions.csv.gz/curve.csv/fit.json,metrics.csv·horizon/condition/peak/day표·run.log.
- 결론과 다음 실험: 동결 설정의8월 추가 확인 RMSE=14.0024kW,Loss C=14.7766kW,N=2972원점. 이결과로재선정하지않았다.9월최종평가는미실행이다.

| fold | scope | n_excluded_origins | n_unique_target_times | Loss_A | MAE | L_mean | L_CVaR | L_peak | Loss_B | Loss_C | tail_windows | n_origins | n_predictions | n_risk_windows | epochs | stop_reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| aug | full | 0 | 2975 | 14.0024 | 9.5065 | 10.5295 | 24.4924 | 10.8207 | 16.1147 | 14.7766 | 595 | 2972 | 11888 | 2972 | 6 | max_epochs |
| aug | clean_targets | 75 | 2903 | 14.1386 | 9.6432 | 10.6758 | 24.6738 | 10.9439 | 16.2750 | 14.9288 | 580 | 2897 | 11588 | 2897 | 6 | max_epochs |
| aug | clean_targets_inputs | 172 | 2806 | 14.1408 | 9.7308 | 10.7691 | 24.6496 | 10.8743 | 16.3213 | 14.9543 | 560 | 2800 | 11200 | 2800 | 6 | max_epochs |

해석 보완 이력: 2026-10-03 저장된 실제 지표·조건표만으로 결론과 큰 오차 조건을 갱신했다. 기존 설정·예측·지표·실패 이력은 변경하지 않았다.
